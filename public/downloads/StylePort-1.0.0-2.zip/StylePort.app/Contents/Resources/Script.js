let statusCheckFinished = false;

// Native code exposes this only in the Developer ID edition.
function showDirectDistribution() {
    const tip = document.querySelector("button.leave-tip");
    tip.textContent = "Support on the website ↗";
    const updates = document.createElement("button");
    updates.className = "privacy-policy";
    updates.textContent = "Check for Updates…";
    updates.addEventListener("click", () => {
        webkit.messageHandlers.controller.postMessage("check-for-updates");
    });
    tip.parentElement.append(document.createTextNode(" · "), updates);
}

function show(enabled, useSettingsInsteadOfPreferences, unavailable = false) {
    statusCheckFinished = true;

    if (useSettingsInsteadOfPreferences) {
        document.getElementsByClassName('open-preferences')[0].innerText = "Open Safari Settings";
    }

    document.body.classList.toggle("state-unavailable", unavailable);

    if (!unavailable && typeof enabled === "boolean") {
        document.body.classList.toggle(`state-on`, enabled);
        document.body.classList.toggle(`state-off`, !enabled);
    } else {
        document.body.classList.remove(`state-on`);
        document.body.classList.remove(`state-off`);
    }
}

function openPreferences() {
    webkit.messageHandlers.controller.postMessage("open-preferences");
}

function openPrivacyPolicy() {
    webkit.messageHandlers.controller.postMessage("open-privacy");
}

document.querySelector("button.open-preferences").addEventListener("click", openPreferences);
document.querySelector("button.privacy-policy").addEventListener("click", openPrivacyPolicy);
document.querySelector("button.leave-tip").addEventListener("click", () => {
    webkit.messageHandlers.controller.postMessage("open-tip-jar");
});
document.querySelector("a.publisher-link").addEventListener("click", event => {
    event.preventDefault();
    webkit.messageHandlers.controller.postMessage("open-publisher");
});

setTimeout(() => {
    if (!statusCheckFinished) show(undefined, true, true);
}, 3000);
