"use strict";

(self.webpackChunkstyleport = self.webpackChunkstyleport || []).push([ [ "import" ], {
  208(_, ee, oe) {
    oe(9073);
    var ae = oe(4930);
    var le = oe(8660);
    const panels = document.querySelectorAll("[data-panel]");
    const modeButtons = document.querySelectorAll(".import-modes [data-mode]");
    const fileInput = document.getElementById("style-file");
    const dropzone = document.querySelector(".file-drop");
    const status = document.getElementById("import-status");
    for (const button of modeButtons) button.onclick = () => selectMode(button.dataset.mode);
    fileInput.onchange = () => importFile(fileInput.files[0]);
    Object.assign(dropzone, {
      ondragover(event) {
        if (event.dataTransfer.types.includes("Files")) {
          event.preventDefault();
          event.dataTransfer.dropEffect = "copy";
          dropzone.classList.add("dragging");
        }
      },
      ondragleave() {
        dropzone.classList.remove("dragging");
      },
      ondrop(event) {
        event.preventDefault();
        dropzone.classList.remove("dragging");
        importFile(event.dataTransfer.files[0]);
      }
    });
    document.querySelector('[data-panel="url"]').onsubmit = async event => {
      event.preventDefault();
      await run(async () => {
        const updateUrl = new URL(document.getElementById("style-url").value).href;
        if (!/^https?:/.test(updateUrl)) throw new Error("Enter an http or https style URL.");
        const normalized = normalize(await ae.API.download(updateUrl), nameFromUrl(updateUrl));
        await ae.API.usercss.openInstaller({
          sourceCode: normalized.code,
          updateUrl: normalized.usercss ? updateUrl : null
        });
      });
    };
    document.querySelector('[data-panel="paste"]').onsubmit = async event => {
      event.preventDefault();
      await run(async () => {
        const normalized = normalize(document.getElementById("style-code").value, document.getElementById("style-name").value);
        await ae.API.usercss.openInstaller({
          sourceCode: normalized.code
        });
      });
    };
    function selectMode(mode) {
      for (const button of modeButtons) {
        const active = button.dataset.mode === mode;
        button.setAttribute("aria-selected", `${active}`);
        button.tabIndex = active ? 0 : -1;
      }
      for (const panel of panels) panel.hidden = panel.dataset.panel !== mode;
      status.textContent = "";
    }
    async function importFile(file) {
      if (file) {
        await run(async () => {
          if (!/\.(?:user\.)?css$/i.test(file.name)) throw new Error("Choose a .css or .user.css file.");
          const normalized = normalize(await file.text(), file.name.replace(/(?:\.user)?\.css$/i, ""));
          await ae.API.usercss.openInstaller({
            sourceCode: normalized.code
          });
        });
        fileInput.value = "";
      }
    }
    async function run(task) {
      const controls = document.querySelectorAll("button, input, textarea");
      controls.forEach(el => el.disabled = !0);
      status.className = "working";
      status.textContent = "Preparing a safe preview…";
      try {
        await task();
        status.className = "success";
        status.textContent = "Preview opened in a new tab. Review the style, then choose Install.";
      } catch (_) {
        status.className = "error";
        status.textContent = _.message || `${_}`;
      } finally {
        controls.forEach(el => el.disabled = !1);
      }
    }
    function normalize(sourceCode, suggestedName = "") {
      const code = `${sourceCode || ""}`.trim();
      if (!code) throw new Error("The style is empty.");
      if (le.getMetaComment(code, "?")) return {
        code,
        usercss: !0
      };
      const name = (suggestedName || "Imported Style").replace(/[\r\n*]+/g, " ").trim() || "Imported Style";
      return {
        usercss: !1,
        code: `${[ "/* ==UserStyle==", `@name           ${name}`, `@namespace      styleport.local/${slugify(name)}`, "@version        1.0.0", "@description    Imported locally with StylePort", "==/UserStyle== */" ].join("\n")}\n\n${code}\n`
      };
    }
    function slugify(name) {
      return name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "imported";
    }
    function nameFromUrl(url) {
      const path = new URL(url).pathname;
      return decodeURIComponent(path.split("/").pop() || "").replace(/(?:\.user)?\.css$/i, "") || "Imported Style";
    }
  }
}, _ => {
  _.O(0, [ "color", "dlg_config-dialog_css-css_dom-error_css-css_global-dark_css-css_global_css-css_onoffswitch_cs-7b17ff" ], () => _(_.s = 208));
  _.O();
} ]);