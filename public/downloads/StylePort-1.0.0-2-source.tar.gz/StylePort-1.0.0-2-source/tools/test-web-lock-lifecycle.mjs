import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {runInNewContext} from 'node:vm';

const helper = (await readFile(new URL('../src/js/web-lock-error.js', import.meta.url), 'utf8'))
  .replace('export function', 'function');
const handleError = runInNewContext(`${helper}\nhandleWebLockError`);
const message = 'Promise was rejected because the browsing context is going away';
const teardown = () => new DOMException(message, 'AbortError');

assert.equal(await Promise.reject(teardown()).catch(handleError), undefined);
for (const error of [new Error(message), new DOMException('User aborted', 'AbortError'),
  new DOMException('Locks denied', 'SecurityError'), new Error('Storage failed'), null]) {
  await assert.rejects(Promise.reject(error).catch(handleError), actual => actual === error);
}

// Exercise the real module's lifetime lock, not just the helper. WebKit may
// reject it after navigation or when the page enters its back/forward cache.
const port = (await readFile(new URL('../src/js/port.js', import.meta.url), 'utf8'))
  .replace(/^import .*;\n/gm, '')
  .replace(/export /g, '');
for (const entry of [true, 'worker', 'sw']) {
  let rejectLock;
  let requested;
  let handler;
  const lockPromise = new Promise((resolve, reject) => { rejectLock = reject; });
  const nativeCatch = lockPromise.catch.bind(lockPromise);
  lockPromise.catch = callback => {
    handler = callback;
    return nativeCatch(callback);
  };
  runInNewContext(`${helper}\n${port}`, {
    __: {ENTRY: entry, MV3: true, DEBUGPORT() {}}, CHROME: 0,
    NOP() {}, location: {pathname: '/edit.html'}, global: {},
    navigator: {vendor: 'Apple Computer, Inc.', locks: {
      request(path) { requested = path; return lockPromise; },
    }},
  });
  assert.equal(requested, '/edit.html');
  assert.equal(typeof handler, 'function', `${entry}: lifetime lock needs a rejection handler`);
  rejectLock(teardown());
  await new Promise(resolve => setImmediate(resolve));
}

// Target monitoring also queries locks and waits on their release; both can
// reject on teardown. Keep its catch at the async task boundary.
assert.match(port, /trackTarget\(queue\)\.catch\(handleWebLockError\)/);
assert.match(port, /bgLock = navLocks\.request\([^;]+\.catch\(handleWebLockError\)/);
console.log('Web Lock navigation cancellation tests passed');
