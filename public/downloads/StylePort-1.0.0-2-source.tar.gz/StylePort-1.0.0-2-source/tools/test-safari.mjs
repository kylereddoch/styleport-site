#!/usr/bin/env node

import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile, readdir, stat} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {runInNewContext} from 'node:vm';
import './test-safari-lifecycle.mjs';
import './test-web-lock-lifecycle.mjs';

const root = new URL('../', import.meta.url);
const dist = new URL('dist-safari/', root);
const xcodeResources = new URL('safari/StylePort/StylePort Extension/Resources/', root);

const json = async url => JSON.parse(await readFile(url, 'utf8'));
const packageJson = await json(new URL('package.json', root));
const sourceManifest = await json(new URL('src/manifest.json', root));
const manifest = await json(new URL('manifest.json', dist));

const projectSource = await readFile(new URL(
  'safari/StylePort/StylePort.xcodeproj/project.pbxproj', root), 'utf8');
const bundleIDs = [...projectSource.matchAll(/PRODUCT_BUNDLE_IDENTIFIER = ([^;]+);/g)]
  .map(match => match[1]).sort();
assert.deepEqual(bundleIDs, [
  'dev.relaybyte.styleport', 'dev.relaybyte.styleport',
  'dev.relaybyte.styleport.safari', 'dev.relaybyte.styleport.safari',
], 'Debug and Release app identities must follow the RelayByte convention');
const containerController = await readFile(new URL(
  'safari/StylePort/StylePort/ViewController.swift', root), 'utf8');
assert.ok(containerController.includes(
  'let extensionBundleIdentifier = "dev.relaybyte.styleport.safari"'),
'native Safari settings lookup must match the extension identity');

assert.equal(manifest.name, 'StylePort');
assert.equal(manifest.manifest_version, 3);
assert.equal(packageJson.version, sourceManifest.version);
assert.equal(manifest.version, packageJson.version);
assert.deepEqual(manifest.host_permissions, ['<all_urls>']);
assert.ok(manifest.permissions.includes('scripting'));

const unsupported = [
  'identity',
  'idle',
  'offscreen',
  'sidePanel',
  'webRequestBlocking',
];
for (const permission of unsupported) {
  assert.ok(!manifest.permissions.includes(permission), `unsupported permission: ${permission}`);
}

assert.deepEqual(manifest.background, {scripts: ['sw.js'], persistent: false});
assert.equal(manifest.commands?._execute_action, undefined);
assert.equal(manifest.content_scripts.length, 1);
assert.deepEqual(manifest.content_scripts[0].js, ['js/apply.js']);
assert.deepEqual(manifest.content_scripts[0].matches, ['<all_urls>']);

const requiredPages = [
  'edit.html',
  'import.html',
  'install-usercss.html',
  'manage.html',
  'options.html',
  'popup.html',
];
for (const file of requiredPages) {
  const html = await readFile(new URL(file, dist), 'utf8');
  assert.ok(!html.includes('js/get-client-data.js'), `${file} preloads Chrome client data`);
}

const importPage = await readFile(new URL('import.html', dist), 'utf8');
assert.match(importPage, /class="publisher-credit"/);
assert.match(importPage, /href="https:\/\/relaybyte\.dev"/);
assert.match(importPage, /app by Kyle Reddoch/);
const containerPage = await readFile(new URL(
  'safari/StylePort/StylePort/Resources/Base.lproj/Main.html', root), 'utf8');
assert.match(containerPage, /href="https:\/\/relaybyte\.dev">RelayByte<\/a> app by Kyle Reddoch/);
assert.match(containerController, /case "open-publisher":[\s\S]*?https:\/\/relaybyte\.dev/);

const popupData = await readFile(new URL('src/background/popup-data.js', root), 'utf8');
assert.ok(
  popupData.includes("typeof chrome.runtime.getContexts === 'function'"),
  'popup data must guard the Chromium-only runtime.getContexts API',
);

const editorPage = await readFile(new URL('edit.html', dist), 'utf8');
assert.ok(
  editorPage.includes('id="cancel-button" i18n="styleManager"'),
  'editor must expose a visible Style Library return control',
);
const managerPage = await readFile(new URL('manage.html', dist), 'utf8');
const optionsPreviewPage = await readFile(new URL('options.html', dist), 'utf8');
for (const surface of ['dark', 'light']) {
  assert.ok(optionsPreviewPage.includes(`class="toolbar-icon-preview on-${surface}"`),
    `toolbar icon preview needs its own ${surface} surface`);
  for (const state of ['', 'w', 'x']) {
    const icon = `icon/${surface === 'light' ? 'light/' : ''}32${state}.png`;
    assert.ok(optionsPreviewPage.includes(`src="${icon}"`));
    assert.ok((await stat(new URL(icon, dist))).size > 0, `missing preview icon: ${icon}`);
  }
}
assert.ok(managerPage.includes('href="styleport://tips"'),
  'library tip button must open the native jar, not a web payment page');
assert.ok(managerPage.includes('target="styleport-tip-launch"'));
assert.match(managerPage, /<iframe name="styleport-tip-launch"[^>]* hidden>/,
  'native app handoff must preserve the library instead of navigating the tab');
assert.ok(managerPage.indexOf('id="backup"') < managerPage.indexOf('id="styleport-tip-link"'));
assert.ok(managerPage.indexOf('id="styleport-tip-link"') < managerPage.indexOf('id="links"'));
assert.ok(!managerPage.includes('id="styleport-support"'),
  'tip link must not have a separate card');
const appDelegate = await readFile(new URL(
  'safari/StylePort/StylePort/AppDelegate.swift', root), 'utf8');
assert.ok(appDelegate.includes('$0.absoluteString == "styleport://tips"'),
  'native tip route must accept only the explicit presentation URL');
assert.match(appDelegate, /open urls: \[URL\][\s\S]*?TipJarController.shared.present\(\)/);
const appInfo = await readFile(new URL(
  'safari/StylePort/StylePort/Info.plist', root), 'utf8');
assert.match(appInfo, /CFBundleURLSchemes[\s\S]*?<string>styleport<\/string>/);
for (const plist of [appInfo, await readFile(new URL(
  'safari/StylePort/StylePort Extension/Info.plist', root), 'utf8')]) {
  assert.match(plist, /<key>ITSAppUsesNonExemptEncryption<\/key>\s*<false\/>/,
    'Safari app and extension must declare their exempt system cryptography');
}
assert.ok(managerPage.includes('<summary i18n="styleportBackupTipsHeading">'),
  'backup reminder must retain its label when collapsed');
assert.ok(managerPage.includes('<summary i18n="styleportFindStylesHeading">'),
  'style discovery must retain its label when collapsed');
for (const href of [
  'https://userstyles.world/explore',
  'https://uso.kkx.one/browse/styles',
  'https://styleport.app/support/',
]) assert.ok(managerPage.includes(`href="${href}"`), `missing library link: ${href}`);
assert.ok(!managerPage.includes('href="https://github.com/openstyles/stylus"'),
  'library discovery panel must not include the upstream GitHub link');
assert.ok(!managerPage.includes('explore.transifex.com'),
  'library discovery panel must not include the translation link');
assert.ok(managerPage.includes('id="import" i18n="restoreBackupLabel"'),
  'library must retain Restore Backup');
assert.ok(managerPage.includes('id="export" i18n="exportLabel"'),
  'library must retain Export');

// Exercise the actual library click handler without requiring browser APIs.
const managerEvents = await readFile(new URL('src/manage/events.js', root), 'utf8');
const editHandler = managerEvents.slice(
  managerEvents.indexOf('async function edit('),
  managerEvents.indexOf('\nfunction expandTargets('),
);
for (const popup of [false, true]) {
  const calls = [];
  const context = {
    API: {
      openEditor: args => calls.push(['editor', args]),
      openURL: args => calls.push(['url', args]),
    },
    browserWindows: {},
    getOwnTab: async () => ({id: 7, index: 2}),
    getEventKeyName: e => e.key,
    kPopup: 'popup',
    sessionStore: {},
    urlParams: new URLSearchParams(popup ? 'popup=1' : ''),
    location: 'manage.html',
  };
  const edit = runInNewContext(`(${editHandler})`, context);
  const event = {key: 'MouseL', preventDefault() {}, stopPropagation() {}};
  const url = 'safari-web-extension://test/edit.html?id=1';
  const entry = {styleId: 1, $: () => ({href: url})};
  await edit(event, entry);
  assert.equal(context.location, url + (popup ? '&popup=1' : ''));
  assert.equal(context.sessionStore.manageStylesHistory7, context.location);
  assert.equal(calls.length, 0, 'ordinary clicks must not open another tab/window');
  await edit({...event, key: 'Shift-MouseL'}, entry);
  assert.equal(calls[0][0], 'editor', 'explicit window shortcut remains available');
  await edit({...event, key: 'Ctrl-MouseL'}, entry);
  assert.equal(calls[1][0], 'url', 'explicit tab shortcut remains available');
}
const editorInit = await readFile(new URL('src/edit/index.js', root), 'utf8');
assert.ok(editorInit.includes("$id('cancel-button').onclick = () => editor.cancel()"),
  'Style Library must use same-tab return navigation and its unload guard');

// Safari popup navigation must use tabs.create, not a native target=_blank link
// or background RPC. Closing before the tab promise settles cancels the flow.
const popupEvents = await readFile(new URL('src/popup/events.js', root), 'utf8');
assert.match(popupEvents, /\[selManager\]: openManager/);
assert.match(popupEvents, /'#import-style-btn': openImport/);
const safariOpen = popupEvents.slice(popupEvents.indexOf('async function openSafariPage('),
  popupEvents.indexOf('\n}\n', popupEvents.indexOf('async function openSafariPage(')) + 2);
for (const path of ['manage.html', 'import.html', 'manage.html#stylus-options']) {
  for (const isSidebar of [false, true]) {
    let settle;
    const calls = [];
    const open = runInNewContext(`(${safariOpen})`, {
      browser: {tabs: {create: args => {
        calls.push(args.url);
        return new Promise(resolve => { settle = resolve; });
      }}},
      chrome: {runtime: {getURL: page => 'safari-web-extension://test/' + page}},
      isSidebar,
      close: () => calls.push('close'),
    });
    const pending = open(path);
    assert.deepEqual(calls, ['safari-web-extension://test/' + path]);
    settle();
    await pending;
    assert.equal(calls.length, isSidebar ? 1 : 2);
  }
}
let closedOnFailure = false;
const failingOpen = runInNewContext(`(${safariOpen})`, {
  browser: {tabs: {create: async () => { throw new Error('tab refused'); }}},
  chrome: {runtime: {getURL: page => page}},
  isSidebar: false,
  close: () => { closedOnFailure = true; },
});
await assert.rejects(failingOpen('manage.html'), /tab refused/);
assert.equal(closedOnFailure, false, 'failed navigation must leave the popup open');

// Safari popovers use CSS pixels: Retina must not halve the options panel.
const globalDark = await readFile(new URL('src/css/global-dark.css', root), 'utf8');
const globalLight = await readFile(new URL('src/css/global.css', root), 'utf8');
assert.match(globalDark,
  /@media screen and \(prefers-color-scheme: dark\), dark \{[\s\S]*?:root\.safari \{/,
  'Safari dark palette must apply before asynchronous background preferences arrive');
assert.ok(!globalLight.includes(':root.safari[data-ui-theme="dark"]'),
  'Safari dark palette must not depend on a delayed data attribute');
const configSource = await readFile(new URL('src/js/dlg/config-dialog.js', root), 'utf8');
const adjustPopupSource = configSource.slice(
  configSource.indexOf('function adjustSizeForPopup('), configSource.lastIndexOf('\n}'));
for (const devicePixelRatio of [1, 2, 3]) {
  for (const availHeight of [900, 600]) {
    const body = {
      style: {cssText: 'min-width:400px;max-width:480px;', maxHeight: '300px'},
      appendChild: () => ({remove() {}}),
    };
    const context = {
      SAFARI: true, MOBILE: false, isSidebar: false, devicePixelRatio,
      screen: {availWidth: 1280, availHeight}, document: {body},
      important: value => value, $create: () => ({}),
      getComputedStyle: () => ({width: '300px'}),
      clamp: (value, min, max) => Math.min(Math.max(value, min), max),
    };
    const adjust = runInNewContext(`(${adjustPopupSource})`, context);
    adjust({
      firstElementChild: {offsetWidth: 900, offsetHeight: 1200},
      classList: {add() {}},
    });
    assert.ok(body.style.cssText.includes('min-width:760px !important'));
    const expectedHeight = Math.min(600, availHeight - 100);
    assert.ok(body.style.cssText.includes(`min-height:${expectedHeight}px !important`));
    assert.equal(body.style.maxHeight, expectedHeight + 'px');
  }
}

const localeRoot = new URL('src/_locales/', root);
for (const locale of await readdir(localeRoot)) {
  const messages = new URL(`${locale}/messages.json`, localeRoot);
  if ((await stat(messages)).isFile()) await json(messages);
}

for (const locale of await readdir(new URL('_locales/', dist))) {
  const path = `_locales/${locale}/messages.json`;
  const messages = await json(new URL(path, dist));
  const description = messages.description?.message;
  assert.equal(typeof description, 'string', `${locale}: Safari description must exist`);
  assert.ok(description.length > 0 && description.length <= 112,
    `${locale}: Safari description must contain 1–112 characters`);
  assert.ok(!description.includes('Stylus'), `${locale}: use StylePort marketing copy`);
  assert.deepEqual(messages, await json(new URL(path, xcodeResources)),
    `${locale}: Xcode must embed the validated locale`);
}

function pngDimensions(buffer) {
  const signature = '89504e470d0a1a0a';
  assert.equal(buffer.subarray(0, 8).toString('hex'), signature);
  assert.equal(buffer.subarray(12, 16).toString('ascii'), 'IHDR');
  return [buffer.readUInt32BE(16), buffer.readUInt32BE(20)];
}

for (const size of [16, 32, 48, 128]) {
  const icon = await readFile(new URL(`icon/${size}.png`, dist));
  assert.deepEqual(pngDimensions(icon), [size, size], `icon/${size}.png dimensions`);
}

// Every toolbar state must retain its size and be distinct in both color modes.
for (const theme of ['', 'light/']) {
  for (const size of [16, 19, 32, 38]) {
    const hashes = new Set();
    for (const suffix of ['', 'w', 'x']) {
      const path = `icon/${theme}${size}${suffix}.png`;
      const icon = await readFile(new URL(path, dist));
      assert.deepEqual(pngDimensions(icon), [size, size], path);
      hashes.add(createHash('sha256').update(icon).digest('hex'));
      assert.deepEqual(icon, await readFile(new URL(`src/${path}`, root)));
    }
    assert.equal(hashes.size, 3, 'Active, no-match and disabled icons must differ');
  }
}
for (const size of [16, 32, 128, 256, 512]) {
  for (const density of [1, 2]) {
    const appIcons = 'safari/StylePort/StylePort/Assets.xcassets/AppIcon.appiconset/';
    const icon = await readFile(new URL(
      `${appIcons}mac-icon-${size}@${density}x.png`, root,
    ));
    assert.deepEqual(pngDimensions(icon), [size * density, size * density]);
  }
}

async function filesBelow(directory, prefix = '') {
  const result = [];
  for (const entry of await readdir(directory, {withFileTypes: true})) {
    const relative = `${prefix}${entry.name}`;
    if (entry.isDirectory()) {
      result.push(...await filesBelow(new URL(`${entry.name}/`, directory), `${relative}/`));
    } else {
      result.push(relative);
    }
  }
  return result.sort();
}

const distFiles = await filesBelow(dist);
const xcodeFiles = await filesBelow(xcodeResources);
assert.deepEqual(xcodeFiles, distFiles, 'Xcode resource list differs from dist-safari');
for (const file of distFiles) {
  const [built, embedded] = await Promise.all([
    readFile(new URL(file, dist)),
    readFile(new URL(file, xcodeResources)),
  ]);
  const digest = data => createHash('sha256').update(data).digest('hex');
  assert.equal(digest(embedded), digest(built), `Xcode resource differs: ${file}`);
}

const project = await readFile(
  new URL('safari/StylePort/StylePort.xcodeproj/project.pbxproj', root), 'utf8',
);
const versions = [...project.matchAll(/MARKETING_VERSION = ([^;]+);/g)].map(match => match[1]);
assert.equal(versions.length, 4);
assert.deepEqual(new Set(versions), new Set([packageJson.version]));
const buildNumbers = [...project.matchAll(/CURRENT_PROJECT_VERSION = ([^;]+);/g)]
  .map(match => match[1]);
assert.equal(buildNumbers.length, 4);
assert.equal(new Set(buildNumbers).size, 1, 'App and extension build numbers must match');
assert.match(buildNumbers[0], /^[1-9]\d*$/);
for (const resource of ['import.html in Resources', 'PrivacyInfo.xcprivacy in Resources']) {
  assert.ok(project.includes(resource), `Xcode project omits ${resource}`);
}

const privacyManifest = new URL('safari/StylePort/StylePort/PrivacyInfo.xcprivacy', root);
const plistCheck = spawnSync(
  'plutil', ['-lint', fileURLToPath(privacyManifest)], {encoding: 'utf8'},
);
assert.equal(plistCheck.status, 0, plistCheck.stderr || plistCheck.stdout);

const tipSource = await readFile(
  new URL('safari/StylePort/StylePort/TipJarController.swift', root), 'utf8',
);
for (const id of ['com.kylereddoch.StylePort.tip.199',
  ...['medium', 'large', 'generous', 'outstanding']
    .map(tier => `dev.relaybyte.styleport.tip.${tier}`)]) {
  assert.ok(tipSource.includes(`"${id}"`), `Tip jar omits Apple product ${id}`);
}
assert.ok(tipSource.includes('import RevenueCat'));
assert.ok(tipSource.includes('PurchaseParams.Builder(package: package)'));
assert.ok(tipSource.includes('params.with(confirmInWindow: window)'),
  'macOS StoreKit confirmation must be anchored to the visible tip window');
assert.ok(tipSource.includes('if #available(macOS 15.2, *)'),
  'window-anchored purchases must preserve support for older macOS');
assert.ok(tipSource.includes('Purchases.shared.purchase(params.build())'));
assert.ok(tipSource.includes('productType == .consumable'));
assert.ok(!tipSource.includes('Transaction.updates'), 'RevenueCat must own transaction finishing');
const privacyText = await readFile(privacyManifest, 'utf8');
assert.ok(privacyText.includes('NSPrivacyCollectedDataTypePurchaseHistory'));
assert.ok(privacyText.includes('NSPrivacyCollectedDataTypePurposeAnalytics'));

console.log(`Safari release checks passed for StylePort ${packageJson.version}.`);
