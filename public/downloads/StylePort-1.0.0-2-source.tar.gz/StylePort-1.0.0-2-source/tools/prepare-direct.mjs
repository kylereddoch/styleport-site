// Generate a separate, reproducible Xcode project without adding Sparkle to
// the App Store target. Source files and Safari resources remain shared.
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {mkdirSync, readFileSync, writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';

const root = fileURLToPath(new URL('../', import.meta.url));
const base = path.join(root, 'safari/StylePort');
const project = JSON.parse(execFileSync('plutil', ['-convert', 'json', '-o', '-',
  path.join(base, 'StylePort.xcodeproj/project.pbxproj')], {encoding: 'utf8'}));
const objects = project.objects;
const app = objects.B60D11AA3007ECE800D66812;
assert.equal(app.name, 'StylePort');
const packageRef = objects.A10200000000000000000003;
assert.match(packageRef.repositoryURL, /RevenueCat/);
packageRef.repositoryURL = 'https://github.com/sparkle-project/Sparkle';
packageRef.requirement = {kind: 'exactVersion', version: '2.10.0'};
objects.A10200000000000000000002.productName = 'Sparkle';
assert.equal(objects.A10100000000000000000002.path, 'TipJarController.swift');
objects.A10100000000000000000002.path = 'DirectSupportController.swift';
objects.B60D11F43007ECE900D66812.path = 'Direct/PrivacyInfo.xcprivacy';
delete objects[project.rootObject].attributes.TargetAttributes
  .B60D11AA3007ECE800D66812.SystemCapabilities['com.apple.InAppPurchase'];
for (const id of objects[app.buildConfigurationList].buildConfigurations) {
  const settings = objects[id].buildSettings;
  settings.INFOPLIST_FILE = 'StylePort/Direct/Info.plist';
  settings.CODE_SIGN_ENTITLEMENTS = 'StylePort/Direct.entitlements';
  settings.SWIFT_ACTIVE_COMPILATION_CONDITIONS = '$(inherited) STYLEPORT_DIRECT';
}
// Xcode embeds the binary framework supplied by the Swift package product.
objects.D10000000000000000000001 = {
  isa: 'PBXFileReference', lastKnownFileType: 'text', name: 'Sparkle-LICENSE.txt',
  path: '../direct/Sparkle-LICENSE.txt', sourceTree: 'SOURCE_ROOT',
};
objects.D10000000000000000000002 = {
  isa: 'PBXBuildFile', fileRef: 'D10000000000000000000001',
};
objects.B60D11A93007ECE800D66812.files.push('D10000000000000000000002');
objects.B60D11AD3007ECE800D66812.children.push('D10000000000000000000001');
const output = path.join(base, 'StylePortDirect.xcodeproj');
mkdirSync(output, {recursive: true});
writeFileSync(path.join(output, 'project.pbxproj'), JSON.stringify(project, null, 2));
execFileSync('plutil', ['-convert', 'xml1', path.join(output, 'project.pbxproj')]);
const lockDir = path.join(output, 'project.xcworkspace/xcshareddata/swiftpm');
mkdirSync(lockDir, {recursive: true});
const lock = path.join(root, 'safari/direct/Package.resolved');
writeFileSync(path.join(lockDir, 'Package.resolved'), readFileSync(lock));
console.log('Prepared direct-only project:', output);
