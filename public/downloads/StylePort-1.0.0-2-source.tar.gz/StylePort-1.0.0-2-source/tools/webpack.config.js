'use strict';

const fs = require('fs');
const webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const HtmlWebpackProcessingPlugin = require('html-webpack-processing-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const CopyPlugin = require('copy-webpack-plugin');
const {RawEnvPlugin} = require('./wp-raw-patch-plugin');
const {
  nukeHtmlSpaces, transESM2var, transSourceMap, BUILD, DEV, HMR, FLAVOR, MANIFEST, MV3, SRC,
} = require('./util');
const augment = require('./webpack.base');
const {
  CSS, JS, SHIM, OUTPUT_MODULE, SEP_ESC, SRC_ESC, THEME_NAMES, THEME_PATH, CM_PATH, DST, ALIASES,
  VARS, DEBUG, GITHUB_ACTIONS,
} = require('./webpack.vars');

global.localStorage = {}; // workaround for node 25 and HtmlWebpackPlugin's `...global`
if (!DEV && fs.existsSync(DST))
  for (const file of fs.readdirSync(DST))
    fs.rmSync(DST + file, {recursive: true});

const {PUBLISH} = process.env;
const PAGE_BG = MV3 ? 'background/sw' : 'background';
const OFFSCREEN = 'offscreen';
const PAGES = [
  'edit',
  'import',
  'install-usercss',
  'manage',
  'options',
  'popup',
  'sidepanel',
  !MV3 && PAGE_BG,
].filter(Boolean);
const GET_CLIENT_DATA = 'get-client-data';
const GET_CLIENT_DATA_TAG = {
  toString: () => `<script src="${JS}${GET_CLIENT_DATA}.js"></script>`,
};
const RESOLVE_VIA_SHIM = {
  modules: [
    SHIM,
    'node_modules',
  ],
};
const MAX_CHUNKNAME_LEN = 24; // in Windows, path+name is limited to 260 chars
const ALIASES_STR = `${
  DEV ? ', ' + ALIASES.map(([k, v]) => `${k}=${v}.bind(document)`).join(', ') : ''
};\n`;
const INTRO = `"use strict";(()=>{ const global=this`;
const INTRO_ALIASES = INTRO + ALIASES_STR;
const addWrapper = (banner = INTRO, footer = '})()', test = /\.js$/) => [
  new webpack.BannerPlugin({raw: true, test, banner}),
  new webpack.BannerPlugin({raw: true, test, banner: footer, footer: true}),
];

function getChunkFileName({chunk}) {
  let res = (chunk.name || chunk.id)
    .replace(/(^|-)(css|js(?=\W)|js_(color|dlg)|vendor-overwrites_.+?_)|_js$/g, '')
    .replace(/node_modules(.+?node_modules)?/g, '')
    .replace(/^[-_]+|[-_]+$|(?<=[-_])[-_]+/g, '')
    .replace(/[-_](css|js)(?=$|[-_])/g, '');
  if (res.length > MAX_CHUNKNAME_LEN) {
    res = res.slice(0, MAX_CHUNKNAME_LEN).replace(/[-_][a-z]{0,2}$/, '');
  }
  res = this[0] + res.replaceAll('_', '-') + this[1];
  return res;
}

function makeLibrary(entry, name, vars) {
  return augment({
    entry,
    output: {
      path: DST + JS,
      library: name && {
        type: 'global',
        name: name?.replace(/^\W+/, ''),
        export: name[0] === '*' ? undefined : 'default',
      },
    },
    plugins: addWrapper(INTRO + ',window=this;'),
  }, undefined, vars);
}

function makeContentScript(name) {
  return augment({
    entry: '@/content/' + name,
    output: {path: DST + JS},
    // (!) `global` must be `this` because in Firefox it's not equal to `window` or `self`
    plugins: addWrapper(
      '"use strict";' +
      `this["${name}"]!==1&&(()=>{` +
      `this["${name}"]=1; const global=this` + ALIASES_STR),
  });
}

function makeManifest(files) {
  let [base, ...mods] = (files[0].sourceFilename.endsWith(MANIFEST) ? files : files.reverse())
    .map(file => file.data.toString());
  base = JSON.parse(MV3 ? base.replace('"browser_action"', '"action"') : base);
  for (let ovr of mods) {
    ovr = JSON.parse(ovr);
    for (const [key, val] of Object.entries(ovr)) {
      const old = base[key];
      if (Array.isArray(old)) old.push(...val);
      else if (old && typeof old === 'object') Object.assign(old, val);
      else base[key] = val;
    }
  }
  let ver = base.version;
  if (BUILD === 'firefox') {
    delete base.key;
  }
  if (MV3 && (DEBUG || DEV)) {
    base.permissions.push('declarativeNetRequestFeedback');
  }
  if (PUBLISH === 'CWS') {
    const isStable = ver.endsWith('.0');
    const extId = isStable
      ? 'clngdbkpkpeebahjckkjfobafhncgmne'
      : 'apmmpaebfobifelkijhaljbmpcgbjbdo';
    if (!isStable) {
      base.name += ` (beta)`;
      ver = base.version = ver.replace(/^2\./, '3.');
      ver += '-beta';
    }
    fs.appendFileSync(process.env.GITHUB_ENV, `EXTENSION_ID=${extId}\n`, 'utf8');
  }
  if (GITHUB_ACTIONS) {
    delete base.key;
  }
  if (HMR) {
    const csp = "script-src 'self' http://localhost:8080; connect-src 'self' *";
    base.content_security_policy = MV3 ? {extension_pages: csp} : csp;
  }
  return JSON.stringify(base, null, 2);
}

function patchStylus(str) {
  const str2 = str.replace(/(?<=segments=)\[new [$\w]+\.Literal\(([$\w]+)\.join\(", "\)\)]/, '$1');
  if (str === str2) throw new Error(patchStylus.name + ' failed!');
  return str2;
}

module.exports = [

  augment({
    entry: Object.fromEntries(PAGES.map(p => [p, `@/${p}`])),
    output: {
      filename: JS + '[name].js',
      chunkFilename: getChunkFileName.bind([JS, '.js']),
    },
    optimization: {
      runtimeChunk: {
        name: 'common',
      },
      splitChunks: {
        chunks: c => !c.name?.match(/jsonlint|lazy/),
        cacheGroups: {
          codemirror: {
            test: new RegExp([
              '/cm/(?!jsonlint)',
              '/codemirror/(?!mode/javascript)',
              '/vendor-overwrites/codemirror',
            ].join('|').replaceAll('/', SEP_ESC)),
            name: 'codemirror',
            enforce: true,
          },
          ...Object.fromEntries([
            [2, 'color', `^${SRC_ESC}js/color/`],
            [1, 'common', `^${SRC_ESC}(content|js)/|/lz-string(-unsafe)?/`],
          ].map(([priority, name, test]) => [name, {
            test: test instanceof RegExp ? test :
              new RegExp(String.raw`(${test.replaceAll('/', SEP_ESC)}).*\.(css|js|html)$`),
            name,
            priority,
          }])),
        },
      },
    },
    plugins: [
      new RawEnvPlugin({
        ENTRY: true,
        THEMES: THEME_NAMES,
      }, {
        IS_BG: MV3 ? 'false' : '(global._bg === true)',
      }),
      ...addWrapper(INTRO_ALIASES),
      new MiniCssExtractPlugin({
        filename: getChunkFileName.bind([CSS, '.css']),
        chunkFilename: getChunkFileName.bind([CSS, '.css']),
      }),
      ...PAGES.map(p => new HtmlWebpackPlugin({
        chunks: [p],
        filename: p + '.html',
        minify: false, // we use nukeHtmlSpaces
        template: SRC + p + '.html',
        templateParameters: (compilation, files, tags, options) => {
          const {bodyTags, headTags} = tags;
          // The main entry goes into BODY to improve performance (2x in manage.html)
          headTags.push(...bodyTags.splice(0, bodyTags.length - 1));
          if (MV3) headTags.unshift(GET_CLIENT_DATA_TAG);
          return {
            __: VARS,
            compilation: compilation,
            webpackConfig: compilation.options,
            htmlWebpackPlugin: {tags, files, options},
          };
        },
        scriptLoading: 'blocking',
        inject: false,
        postProcessing: nukeHtmlSpaces,
      })),
      new HtmlWebpackProcessingPlugin(),
      new CopyPlugin({
        patterns: [
          {context: SRC, from: 'icon/**', to: DST},
          {context: SRC + 'content', from: 'install*.js', to: DST + JS},
          {context: SRC, from: MANIFEST.replace('.', `?(-${FLAVOR}*).`), to: MANIFEST,
            transformAll: makeManifest},
          {context: SRC, from: '_locales/**', to: DST},
          {context: THEME_PATH, from: '*.css', to: DST + CM_PATH},
          ...[
            ['csslint-mod/dist/csslint.js', 'csslint.js', true],
            ['csslint-mod/dist/parserlib.js', 'parserlib.js', true],
            ['stylelint-bundle', 'stylelint.js'],
            ['stylus-lang-bundle/dist/stylus-lang-bundle.min.js', 'stylus-lang.js', 0, patchStylus],
          ].flatMap(([npm, to, mod, patch]) => [{
            transform: mod
              ? transESM2var
              : transSourceMap.bind({map: DEV && `${to}.map`, patch}),
            from: (npm = require.resolve(npm)),
            to: (to = DST + JS + to),
            info: {minimized: !mod},
          }, DEV && !mod && {
            from: npm + '.map',
            to: to + '.map',
          }].filter(Boolean)),
        ],
      }),
      !GITHUB_ACTIONS && new webpack.ProgressPlugin(),
    ].filter(Boolean),
    resolve: RESOLVE_VIA_SHIM,
    devServer: HMR && {
      hot: true,
      liveReload: true,
      client: {webSocketURL: 'ws://localhost:8080/ws'},
      devMiddleware: {writeToDisk: true},
      // allowedHosts: 'all',
      // headers: {'Access-Control-Allow-Origin': '*'},
    },
  }),

  MV3 && augment({
    entry: `@/${PAGE_BG}`,
    plugins: [
      new RawEnvPlugin({
        ENTRY: 'sw',
        IS_BG: true,
      }, {
        KEEP_ALIVE: 'global.keepAlive',
      }),
      ...addWrapper(),
    ],
    resolve: RESOLVE_VIA_SHIM,
  }),

  MV3 && augment({
    entry: `@/${OFFSCREEN}`,
    output: {
      filename: JS + '[name].js',
    },
    plugins: [
      new RawEnvPlugin({ENTRY: OFFSCREEN}),
      ...addWrapper(INTRO_ALIASES),
      new HtmlWebpackPlugin({
        chunks: [OFFSCREEN],
        filename: OFFSCREEN + '.html',
        template: SRC + OFFSCREEN + '.html',
        scriptLoading: 'blocking',
        inject: false,
      }),
    ],
    resolve: RESOLVE_VIA_SHIM,
  }),

  MV3 && augment(OUTPUT_MODULE, augment({
    entry: '@/js/' + GET_CLIENT_DATA,
    output: {path: DST + JS},
  })),

  MV3 && makeLibrary('db-to-cloud/lib/drive/webdav', 'webdav'),

  makeContentScript('apply.js'),
  makeContentScript('hook-uso.js'),
  MV3 && makeContentScript('hook-uso-page-mv3.js'),
  makeLibrary('@/js/worker', undefined, {ENTRY: 'worker'}),
  makeLibrary({less: 'less/lib/less-browser/bootstrap'}, 'less'),
].filter(Boolean);

module.exports.parallelism = 2;
