// Local-only release test. Never changes or publishes the production appcast.
import {createServer} from 'node:http';
import {createReadStream, mkdirSync, readFileSync, statSync, writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import path from 'node:path';

const candidate = path.resolve(process.argv[2]);
const output = path.resolve('.build/qa/sparkle-build2');
const port = 18769;
mkdirSync(output, {recursive: true});
const xml = readFileSync(path.join(candidate, 'appcast.xml'), 'utf8')
  .replaceAll('https://styleport.app/downloads/', `http://127.0.0.1:${port}/`)
  .replaceAll('https://styleport.app/updates/', `http://127.0.0.1:${port}/`);
const feed = path.join(output, 'appcast.xml');
writeFileSync(feed, xml);
execFileSync('.build/sparkle-tools/bin/sign_update',
  ['--account', 'dev.relaybyte.styleport', feed], {stdio: 'inherit'});
const files = new Map([['/appcast.xml', feed]]);
for (const match of xml.matchAll(/http:\/\/127\.0\.0\.1:18769\/([^<"\s]+)/g)) {
  const name = match[1];
  if (name !== path.basename(name)) throw new Error('Unsafe test URL');
  files.set(`/${name}`, path.join(candidate, name));
}
createServer((req, res) => {
  const file = files.get(req.url);
  console.log(`${req.method} ${req.url} ${file ? 200 : 404}`);
  if (!file || !['GET', 'HEAD'].includes(req.method)) {
    res.writeHead(404).end();
    return;
  }
  res.writeHead(200, {'Content-Length': statSync(file).size,
    'Content-Type': file.endsWith('.xml') ? 'application/xml' :
      file.endsWith('.html') ? 'text/html; charset=utf-8' : 'application/octet-stream'});
  if (req.method === 'HEAD') res.end();
  else createReadStream(file).pipe(res);
}).listen(port, '127.0.0.1', () => console.log(`Test feed: http://127.0.0.1:${port}/appcast.xml`));
