export const {URL} = global;
