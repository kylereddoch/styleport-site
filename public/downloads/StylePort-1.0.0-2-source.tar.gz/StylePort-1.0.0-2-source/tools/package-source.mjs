import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {
  copyFileSync, existsSync, lstatSync, mkdirSync, readdirSync, readFileSync, writeFileSync,
} from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
process.chdir(root);
const output = path.resolve(process.argv[2] || '.build/direct-release-build2/website');
const version = JSON.parse(readFileSync('package.json')).version;
const project = readFileSync('safari/StylePort/StylePort.xcodeproj/project.pbxproj', 'utf8');
const builds = [...project.matchAll(/CURRENT_PROJECT_VERSION = (\d+);/g)].map(m => m[1]);
assert(builds.length === 4 && new Set(builds).size === 1);
const name = `StylePort-${version}-${builds[0]}-source`;
const stage = path.resolve('.build/source-staging', name);
const archive = path.join(output, `${name}.tar.gz`);
assert(!existsSync(stage) && !existsSync(archive), 'Refusing to overwrite a source snapshot.');
const inputs = ['src', 'tools', 'safari', 'docs', 'brand/source', 'brand/fonts',
  'brand/README.md', 'LICENSE', 'NOTICE.md', 'PRIVACY.md', 'README.md', 'BUILD.md',
  'CONTRIBUTING.md', 'SECURITY.md', 'package.json', 'pnpm-lock.yaml',
  'pnpm-workspace.yaml', 'babel.config.js', 'eslint.config.js', 'jsconfig.json',
  'postcss.config.js', '.editorconfig', '.gitattributes', '.gitignore'];
const manifest = [];
const excluded = new Set(['xcuserdata', 'StylePortDirect.xcodeproj', '.DS_Store', '__pycache__']);
function copy(relative) {
  if (relative.split(path.sep).some(part => excluded.has(part))) return;
  const source = path.join(root, relative);
  const stat = lstatSync(source);
  assert(!stat.isSymbolicLink(), `Review source symlink before packaging: ${relative}`);
  if (stat.isDirectory()) {
    for (const child of readdirSync(source).sort()) copy(path.join(relative, child));
    return;
  }
  assert(stat.isFile(), `Unsupported source entry: ${relative}`);
  assert(!/\.(?:p8|p12|key|mobileprovision|provisionprofile)$|(?:^|\/)\.env(?:\.|$)/i.test(relative),
    `Private signing/configuration file must not be packaged: ${relative}`);
  const destination = path.join(stage, relative);
  mkdirSync(path.dirname(destination), {recursive: true});
  copyFileSync(source, destination);
  manifest.push(`${createHash('sha256').update(readFileSync(source)).digest('hex')}  ${relative}`);
}
for (const input of inputs) copy(input);
writeFileSync(path.join(stage, 'SOURCE-SHA256SUMS'), `${manifest.sort().join('\n')}\n`);
mkdirSync(output, {recursive: true});
execFileSync('tar', ['--no-mac-metadata', '-czf', archive, '-C', path.dirname(stage), name],
  {stdio: 'inherit', env: {...process.env, COPYFILE_DISABLE: '1'}});
const hash = createHash('sha256').update(readFileSync(archive)).digest('hex');
writeFileSync(`${archive}.sha256`, `${hash}  ${path.basename(archive)}\n`);
console.log(`Prepared ${manifest.length} source files: ${archive}`);
console.log('Excluded build outputs, user libraries/backups, Xcode user state,',
  'and signing credentials.');
