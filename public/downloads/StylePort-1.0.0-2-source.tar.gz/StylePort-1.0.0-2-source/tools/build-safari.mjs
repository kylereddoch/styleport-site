#!/usr/bin/env node

import {cp, readFile, readdir, rm, writeFile} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';

const source = new URL('../dist-chrome-mv3/', import.meta.url);
const destination = new URL('../dist-safari/', import.meta.url);
const xcodeResources = new URL(
  '../safari/StylePort/StylePort Extension/Resources/', import.meta.url,
);

const build = spawnSync(process.execPath, ['tools/build.js'], {
  cwd: new URL('..', import.meta.url),
  env: {...process.env, npm_lifecycle_event: 'build-chrome-mv3'},
  stdio: 'inherit',
});

if (build.status) process.exit(build.status);

await rm(destination, {recursive: true, force: true});
await cp(source, destination, {recursive: true});

const manifestUrl = new URL('manifest.json', destination);
const manifest = JSON.parse(await readFile(manifestUrl, 'utf8'));

delete manifest.minimum_chrome_version;
delete manifest.key;

// Safari can terminate an MV3 service worker while an extension-page request
// is in flight, disconnecting StylePort's long-lived message ports. Safari MV3
// also supports a nonpersistent background page, which preserves the same
// event-driven lifecycle while keeping those requests connected.
if (manifest.background?.service_worker) {
  manifest.background = {
    scripts: [manifest.background.service_worker],
    persistent: false,
  };
}

// Safari reports the MV3 toolbar shortcut as an invalid empty command. The
// toolbar action still works without this optional keyboard-command entry.
delete manifest.commands?._execute_action;
if (!Object.keys(manifest.commands || {}).length) delete manifest.commands;

const unsupportedPermissions = new Set([
  'identity',
  'idle',
  'offscreen',
  'sidePanel',
  'webRequestBlocking',
]);
manifest.permissions = manifest.permissions.filter(
  permission => !unsupportedPermissions.has(permission),
);

// StylePort's Safari experience intentionally imports styles through its own
// review screen. Remove inherited marketplace hooks so opening a third-party
// gallery never injects code or suggests an unrelated installation path.
manifest.content_scripts = (manifest.content_scripts || []).filter(
  script => script.js?.includes('js/apply.js'),
);

for (const script of manifest.content_scripts || []) {
  delete script.match_about_blank;
  delete script.match_origin_as_fallback;
  delete script.world;
}

for (const resource of manifest.web_accessible_resources || []) {
  delete resource.use_dynamic_url;
}

await writeFile(manifestUrl, `${JSON.stringify(manifest, null, 2)}\n`);

// App Store validation limits Safari's localized extension description to 112
// characters. Keep a concise StylePort fallback until brand-specific
// translations are available; do not ship inherited Stylus marketing copy.
const safariDescription = 'Customize websites with your own CSS and UserCSS. ' +
  'Import, edit, and back up styles locally in Safari.';
for (const locale of await readdir(new URL('_locales/', destination))) {
  const url = new URL(`_locales/${locale}/messages.json`, destination);
  const messages = JSON.parse(await readFile(url, 'utf8'));
  messages.description = {message: safariDescription};
  await writeFile(url, `${JSON.stringify(messages, null, 2)}\n`);
}

// Chromium preloads extension-page data through InstallEvent.addRoutes().
// Safari doesn't implement that API, so its pages use the existing async
// background-message path instead.
for (const fileName of (await readdir(destination)).filter(file => file.endsWith('.html'))) {
  const url = new URL(fileName, destination);
  const html = (await readFile(url, 'utf8'))
    .replace('<script src="js/get-client-data.js"></script>', '');
  await writeFile(url, html);
}

// Keep Xcode's embedded resource tree identical to the validated web build.
await rm(xcodeResources, {recursive: true, force: true});
await cp(destination, xcodeResources, {recursive: true});

console.log('Safari extension prepared in dist-safari/ and synchronized with Xcode.');
