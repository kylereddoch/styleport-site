#!/usr/bin/env python3
"""Build Layered Portal assets. Requires Pillow, fontTools, Node/sharp and ttf2woff2."""
from pathlib import Path
import json
import shutil
import subprocess
import zipfile
from PIL import Image, ImageDraw, ImageFont
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen

ROOT = Path(__file__).resolve().parents[1]
BRAND = ROOT / 'brand'
OUT = BRAND / 'exports'
ICON = ROOT / 'src/icon'
APP = ROOT / 'safari/StylePort/StylePort'
INK, WHITE = '#111522', '#F5F7FC'


def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)


def svg(body, width=1254, height=1254):
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}">{body}</svg>'


def symbol(color=INK, mono=False):
    # Scalable interpretation of the approved perspective window and three sheets.
    defs = '<defs><linearGradient id="mint" x2="1" y2=".6"><stop stop-color="#5EEAD4"/><stop offset="1" stop-color="#5795F8"/></linearGradient><linearGradient id="coral" x2=".4" y2="1"><stop stop-color="#FDA4AF"/><stop offset="1" stop-color="#FB7185"/></linearGradient></defs>'
    rear = color if mono else 'url(#coral)'
    middle = color if mono else '#8B5CF6'
    front = color if mono else 'url(#mint)'
    return defs + f'''<path fill="{rear}" d="M807 655 1081 775 Q1120 792 1120 834 L1120 972 Q1120 1037 1065 1014 L812 909Z"/>
<path fill="{color}" fill-rule="evenodd" d="M283 253Q283 144 384 164L963 304Q1039 322 1039 398V903Q1039 927 1016 916L934 878V508Q934 472 904 460L416 333Q391 326 391 357V790Q391 827 427 841L852 1004Q882 1017 882 1043V1067Q882 1146 812 1119L349 921Q283 893 283 822ZM369 252a26 27 0 1 0 52 0a26 27 0 1 0-52 0M449 272a26 27 0 1 0 52 0a26 27 0 1 0-52 0M530 292a26 27 0 1 0 52 0a26 27 0 1 0-52 0"/>
<path fill="{middle}" d="M484 549 873 625Q907 640 907 678V915Q907 972 855 950L516 813Q480 798 480 762Z"/>
<path fill="{front}" d="M138 534 498 446Q516 441 538 447L803 514Q840 524 840 563V819Q840 875 791 853L134 584Q90 563 138 534Z"/>'''


def toolbar(color, disabled=False):
    # Pixel-oriented silhouette: omit tiny window dots and gradients.
    body = f'''<g fill="none" stroke="{color}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12.5 14.4 5 11.6V2.4Q5 1.5 5.9 1.8L13.4 4Q14.2 4.2 14.2 5V11.7"/><path d="M2 6.3 7.4 4.9 11.6 6.1V10.6Z" fill="{color}" stroke-width=".7"/><path d="m7.6 10.5 5.4 2"/></g>'''
    if disabled:
        body += f'<path d="m2 2 12 12" stroke="{color}" stroke-width="1.6" stroke-linecap="round"/>'
    return svg(body, 16, 16)


def outlined_wordmark():
    font = instantiateVariableFont(TTFont(BRAND / 'fonts/Manrope-Variable.ttf'), {'wght': 800})
    glyphs, cmap = font.getGlyphSet(), font.getBestCmap()
    scale = 120 / font['head'].unitsPerEm
    x, paths = 0, []
    for char in 'StylePort':
        name = cmap[ord(char)]
        pen = SVGPathPen(glyphs)
        glyphs[name].draw(TransformPen(pen, (scale, 0, 0, -scale, x, 130)))
        paths.append(f'<path d="{pen.getCommands()}"/>')
        x += font['hmtx'][name][0] * scale - 2
    return ''.join(paths), round(x + 4)


def save_png(im, path, size):
    path.parent.mkdir(parents=True, exist_ok=True)
    im.resize((size, size), Image.Resampling.LANCZOS).save(path, optimize=True)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    app = Image.open(BRAND / 'source/app-icon-master.png').convert('RGBA')
    for size in (16, 32, 48, 64, 128, 180, 192, 256, 512, 1024):
        save_png(app, OUT / f'app/styleport-app-{size}.png', size)
    for size in (16, 32, 128, 256, 512):
        for density in (1, 2):
            save_png(app, APP / f'Assets.xcassets/AppIcon.appiconset/mac-icon-{size}@{density}x.png', size*density)
    for size in (48, 128):
        save_png(app, ICON / f'{size}.png', size)
    save_png(app, APP / 'Resources/Icon.png', 320)
    word, width = outlined_wordmark()
    jobs = []
    for theme, color in (('light', INK), ('dark', WHITE)):
        for mono in (False, True):
            name = f'styleport-symbol-{theme}' + ('-mono' if mono else '')
            path = OUT / f'logo/{name}.svg'
            write(path, svg(symbol(color, mono)))
            jobs.append([str(path), str(path.with_suffix('.png')), 1024])
        path = OUT / f'logo/styleport-wordmark-{theme}.svg'
        write(path, svg(f'<g fill="{color}">{word}</g>', width, 166))
        jobs.append([str(path), str(path.with_suffix('.png')), width*2])
        path = OUT / f'logo/styleport-lockup-{theme}.svg'
        body = f'<g transform="scale(.16)">{symbol(color)}</g><g transform="translate(218 18)" fill="{color}">{word}</g>'
        write(path, svg(body, width+240, 210))
        jobs.append([str(path), str(path.with_suffix('.png')), (width+240)*2])
        for state, tint, suffix in (('active', color, ''), ('no-match', '#94A3B8' if theme == 'dark' else '#64748B', 'w'), ('disabled', '#FDA4AF' if theme == 'dark' else '#BE123C', 'x')):
            path = OUT / f'toolbar/styleport-toolbar-{theme}-{state}.svg'
            write(path, toolbar(tint, state == 'disabled'))
            for size in (16, 19, 32, 38):
                target = ICON / ('light' if theme == 'light' else '') / f'{size}{suffix}.png'
                jobs.append([str(path), str(target), size])
                jobs.append([str(path), str(path.with_name(f'{path.stem}-{size}.png')), size])
    subprocess.run(['node', '-e', '''const sharp=require('sharp'),fs=require('fs');
const jobs=JSON.parse(fs.readFileSync(0,'utf8'));
Promise.all(jobs.map(async([src,dest,width])=>{fs.mkdirSync(require('path').dirname(dest),{recursive:true});await sharp(src,{density:288}).resize({width}).png().toFile(dest)})).catch(e=>{console.error(e);process.exit(1)});'''], input=json.dumps(jobs), text=True, check=True)
    (OUT / 'fonts').mkdir(exist_ok=True)
    for name in ('Manrope-Variable.ttf', 'OFL.txt'):
        shutil.copy2(BRAND / 'fonts' / name, OUT / 'fonts' / name)
    subprocess.run(['node', '-e', "const fs=require('fs'),convert=require('ttf2woff2').default;fs.writeFileSync(process.argv[2],convert(fs.readFileSync(process.argv[1])));", str(BRAND / 'fonts/Manrope-Variable.ttf'), str(OUT / 'fonts/Manrope-Variable.woff2')], cwd=ROOT, check=True)
    shutil.copy2(BRAND / 'README.md', OUT / 'README.md')
    preview = Image.new('RGB', (1440, 1020), '#EEF1F7')
    draw = ImageDraw.Draw(preview)
    font = ImageFont.truetype(str(BRAND / 'fonts/Manrope-Variable.ttf'), 24)
    draw.text((48, 28), 'StylePort — production asset family', fill=INK, font=font)
    for theme, y, bg in (('light', 100, '#FFFFFF'), ('dark', 550, INK)):
        draw.rounded_rectangle((24, y, 1416, y+420), radius=24, fill=bg)
        art=app.resize((300,300), Image.Resampling.LANCZOS)
        preview.paste(art,(55,y+50),art)
        lock=Image.open(OUT / f'logo/styleport-lockup-{theme}.png')
        lock.thumbnail((920,260),Image.Resampling.LANCZOS)
        preview.paste(lock,(420,y+35),lock)
        for i,size in enumerate((16,19,32,38)):
            im=Image.open(OUT / f'toolbar/styleport-toolbar-{theme}-active-{size}.png')
            preview.paste(im,(460+i*120,y+295),im)
            draw.text((450+i*120,y+340),f'{size} px',fill=INK if theme=='light' else WHITE,font=font)
    preview.save(OUT / 'asset-preview.png')
    with zipfile.ZipFile(BRAND / 'styleport-brand-assets.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(OUT.rglob('*')):
            if path.is_file():
                archive.write(path, 'styleport-brand-assets/' + str(path.relative_to(OUT)))
    print(f'Exported brand files to {OUT}')


if __name__ == '__main__':
    main()
