import assert from 'node:assert/strict';
import {execFileSync, spawnSync} from 'node:child_process';
import {existsSync, readFileSync} from 'node:fs';
import path from 'node:path';

const plist = file => JSON.parse(execFileSync('plutil',
  ['-convert', 'json', '-o', '-', file], {encoding: 'utf8'}));
const source = plist('safari/StylePort/StylePort.xcodeproj/project.pbxproj');
const generated = plist('safari/StylePort/StylePortDirect.xcodeproj/project.pbxproj');
const dependency = 'A10200000000000000000002';
assert.equal(source.objects[dependency].productName, 'RevenueCat');
assert.equal(generated.objects[dependency].productName, 'Sparkle');
assert(!JSON.stringify(source).includes('STYLEPORT_DIRECT'));
assert(!JSON.stringify(source).includes('sparkle-project'));
assert(!JSON.stringify(generated).includes('RevenueCat'));
const info = plist('safari/StylePort/StylePort/Direct/Info.plist');
assert.equal(info.SUFeedURL, 'https://styleport.app/updates/appcast.xml');
assert.equal(Buffer.from(info.SUPublicEDKey, 'base64').length, 32);
assert.equal(info.SURequireSignedFeed, true);
assert.equal(info.SUVerifyUpdateBeforeExtraction, true);
assert.equal(info.SUEnableSystemProfiling, false);
assert.equal(info.SUAutomaticallyUpdate, false);
assert.equal(info.SUEnableAutomaticChecks, undefined, 'Let Sparkle ask for opt-in.');
assert.equal(info.StylePortRevenueCatPublicKey, undefined);
assert.equal(plist('safari/StylePort/StylePort/Direct/PrivacyInfo.xcprivacy')
  .NSPrivacyCollectedDataTypes.length, 0);
const app = process.argv[2];
if (app) {
  const contents = path.join(app, 'Contents');
  const built = plist(path.join(contents, 'Info.plist'));
  assert.equal(built.CFBundleIdentifier, 'dev.relaybyte.styleport');
  assert.equal(built.SUPublicEDKey, info.SUPublicEDKey);
  assert.equal(built.SUFeedURL, info.SUFeedURL);
  assert.equal(built.StylePortRevenueCatPublicKey, undefined);
  assert(existsSync(path.join(contents, 'Frameworks/Sparkle.framework')));
  assert(existsSync(path.join(contents, 'Resources/Sparkle-LICENSE.txt')));
  const executable = path.join(contents, 'MacOS/StylePort');
  const imports = execFileSync('otool', ['-L', executable], {encoding: 'utf8'});
  assert(imports.includes('Sparkle.framework'));
  assert(!imports.includes('RevenueCat'));
  assert(!readFileSync(executable).includes(Buffer.from('appl_Mwheq')));
  execFileSync('codesign', ['--verify', '--deep', '--strict', app], {stdio: 'inherit'});
  const sparkle = path.join(contents, 'Frameworks/Sparkle.framework/Versions/B');
  for (const component of [app, path.join(contents, 'PlugIns/StylePort Extension.appex'),
    path.join(contents, 'Frameworks/Sparkle.framework'), path.join(sparkle, 'Autoupdate'),
    path.join(sparkle, 'Updater.app'), path.join(sparkle, 'XPCServices/Installer.xpc'),
    path.join(sparkle, 'XPCServices/Downloader.xpc')]) {
    const identity = spawnSync('codesign', ['-dv', '--verbose=4', component], {encoding: 'utf8'});
    assert.equal(identity.status, 0, component);
    assert(identity.stderr.includes('Authority=Developer ID Application:'), component);
    assert(identity.stderr.includes('TeamIdentifier=HF55W68A43'), component);
    assert(identity.stderr.includes('runtime'), component);
  }
  const architectures = execFileSync('lipo', ['-archs', executable], {encoding: 'utf8'});
  assert(architectures.includes('arm64') && architectures.includes('x86_64'));
  const entitlements = spawnSync('codesign', ['-d', '--entitlements', ':-', app],
    {encoding: 'utf8'});
  assert.equal(entitlements.status, 0);
  assert(entitlements.stdout.includes('dev.relaybyte.styleport-spks'));
  assert(entitlements.stdout.includes('dev.relaybyte.styleport-spki'));
  assert(!entitlements.stdout.includes('com.apple.security.get-task-allow'));
  execFileSync('spctl', ['--assess', '--type', 'execute', '--verbose=2', app], {stdio: 'inherit'});
}
console.log('Direct distribution isolation and updater checks passed.');
