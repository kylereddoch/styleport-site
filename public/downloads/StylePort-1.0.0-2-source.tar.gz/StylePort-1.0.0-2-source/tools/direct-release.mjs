import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {
  copyFileSync, existsSync, mkdirSync, readFileSync, renameSync, writeFileSync,
} from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import path from 'node:path';

const root = fileURLToPath(new URL('../', import.meta.url));
process.chdir(root);
process.env.DEVELOPER_DIR ||= '/Applications/Xcode.app/Contents/Developer';
const command = process.argv[2];
const archive = path.resolve(process.env.STYLEPORT_ARCHIVE || '.build/StylePort-direct.xcarchive');
const output = path.resolve(process.env.STYLEPORT_OUTPUT || '.build/direct-release');
const derived = path.resolve('.build/safari-direct');
const app = path.join(output, 'StylePort.app');
const run = (exe, args) => execFileSync(exe, args, {stdio: 'inherit'});
const plist = file => JSON.parse(execFileSync('plutil',
  ['-convert', 'json', '-o', '-', file], {encoding: 'utf8'}));

switch (command) {
  case 'archive':
    assert(!existsSync(archive),
      `Archive already exists; choose a new STYLEPORT_ARCHIVE: ${archive}`);
    run(process.execPath, ['tools/prepare-direct.mjs']);
    run(process.execPath, ['tools/test-safari.mjs']);
    try {
      run('xcodebuild', ['archive', '-project', 'safari/StylePort/StylePortDirect.xcodeproj',
        '-scheme', 'StylePort', '-configuration', 'Release',
        '-destination', 'generic/platform=macOS',
        '-archivePath', archive, '-derivedDataPath', derived,
        '-clonedSourcePackagesDirPath', '.build/direct-packages',
        '-allowProvisioningUpdates', 'REGISTER_APP=NO']);
    } finally {
      // Xcode may register the temporary extension even with REGISTER_APP=NO.
      const temporary = path.join(derived, 'Build/Intermediates.noindex/ArchiveIntermediates',
        'StylePort/InstallationBuildProductsLocation/Applications/StylePort.app',
        'Contents/PlugIns/StylePort Extension.appex');
      if (existsSync(temporary)) run('pluginkit', ['-r', temporary]);
    }
    break;
  case 'notarize':
    run('xcodebuild', ['-exportArchive', '-archivePath', archive,
      '-exportOptionsPlist', 'safari/direct/NotarizeOptions.plist',
      '-exportPath', `${output}-submission`, '-allowProvisioningUpdates']);
    console.log('Submitted to Apple. Upload success is not approval. Run export next.');
    break;
  case 'export':
    run('xcodebuild', ['-exportNotarizedApp', '-archivePath', archive, '-exportPath', output]);
    run('xcrun', ['stapler', 'validate', app]);
    run('codesign', ['--verify', '--deep', '--strict', '--verbose=2', app]);
    run('spctl', ['--assess', '--type', 'execute', '--verbose=2', app]);
    break;
  case 'package': { // Never uploads or publishes the resulting files.
    run('xcrun', ['stapler', 'validate', app]);
    run(process.execPath, ['tools/test-direct.mjs', app]);
    const info = plist(path.join(app, 'Contents/Info.plist'));
    const version = info.CFBundleShortVersionString;
    const build = info.CFBundleVersion;
    assert.match(version, /^\d+(?:\.\d+)*$/);
    assert.match(build, /^\d+(?:\.\d+)*$/);
    const release = path.join(output, 'website');
    const notesSource = path.join(root, 'docs/releases', `${version}-${build}.html`);
    assert(existsSync(notesSource), `Missing reviewed release notes: ${notesSource}`);
    mkdirSync(release, {recursive: true});
    const zip = path.join(release, `StylePort-${version}-${build}.zip`);
    assert(!existsSync(zip), 'Refusing to overwrite a signed release archive.');
    run('ditto', ['-c', '-k', '--sequesterRsrc', '--keepParent', app, zip]);
    const hash = createHash('sha256').update(readFileSync(zip)).digest('hex');
    writeFileSync(`${zip}.sha256`, `${hash}  ${path.basename(zip)}\n`);
    const generatedNotes = zip.replace(/\.zip$/, '.html');
    copyFileSync(notesSource, generatedNotes);
    const bin = path.resolve(process.env.SPARKLE_BIN || '.build/sparkle-tools/bin');
    run(path.join(bin, 'generate_appcast'), ['--account', 'dev.relaybyte.styleport',
      '--download-url-prefix', 'https://styleport.app/downloads/',
      '--release-notes-url-prefix', 'https://styleport.app/updates/',
      '--link', 'https://styleport.app/', '--maximum-deltas', '0', release]);
    const notesName = `release-notes-${version}-${build}.html`;
    renameSync(generatedNotes, path.join(release, notesName));
    const feed = path.join(release, 'appcast.xml');
    const xml = readFileSync(feed, 'utf8');
    const oldNotesURL = `https://styleport.app/updates/${path.basename(generatedNotes)}`;
    assert(xml.includes(oldNotesURL), 'Generated feed is missing release notes.');
    writeFileSync(feed, xml.replaceAll(oldNotesURL, `https://styleport.app/updates/${notesName}`));
    // Renaming the notes link changes feed bytes, so regenerate its signature.
    run(path.join(bin, 'sign_update'), ['--account', 'dev.relaybyte.styleport', feed]);
    run(path.join(bin, 'sign_update'), ['--account', 'dev.relaybyte.styleport',
      '--verify', path.join(release, 'appcast.xml')]);
    console.log('Prepared locally. Publish ZIP + checksum under /downloads/ and appcast.xml under',
      '/updates/ only after approval. Test a signed update on an installed direct build first.');
    break;
  }
  default:
    throw new Error('Usage: node tools/direct-release.mjs archive|notarize|export|package');
}
