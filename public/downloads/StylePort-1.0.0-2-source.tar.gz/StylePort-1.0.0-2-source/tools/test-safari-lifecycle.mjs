import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {runInNewContext} from 'node:vm';

const sourceUrl = new URL('../src/background/style-via-api.js', import.meta.url);
const source = (await readFile(sourceUrl, 'utf8'))
  .replace(/^import .*;\n/gm, '')
  .replace(/export default function /g, 'function ')
  .replace(/export function /g, 'function ');
const contentSource = await readFile(new URL('../src/content/apply.js', import.meta.url), 'utf8');
const handler = contentSource.slice(contentSource.indexOf('function applyOnMessage('),
  contentSource.indexOf('\nfunction processThrottled('));
const documents = new Map();
const inserted = [];
const removed = [];
let code = 'body { color: purple }';
const clone = value => JSON.parse(JSON.stringify(value));
function documentAt(tabId, frameId = 0) {
  const ctx = {
    SAFARI: true, __: {ENTRY: false}, matchUrl: 'https://example.com/', apiStyleState: {},
  };
  const onMessage = runInNewContext(`(${handler})`, ctx);
  documents.set(`${tabId}:${frameId}`, onMessage);
}
const browser = {
  tabs: {
    async sendMessage(tabId, {data}, {frameId}) {
      const onMessage = documents.get(`${tabId}:${frameId}`);
      if (!onMessage) throw new Error('No receiver');
      return {data: clone(onMessage(clone(data)))};
    },
  },
  webNavigation: {
    async getAllFrames({tabId}) {
      return [...documents.keys()].filter(key => key.startsWith(tabId + ':'))
        .map(key => ({frameId: +key.split(':')[1]}));
    },
  },
  scripting: {
    async insertCSS({css, target}) { inserted.push({css, target}); },
    async removeCSS({css, target}) { removed.push({css, target}); },
  },
};
function background() {
  const listeners = new Set();
  const event = {addListener: fn => listeners.add(fn), removeListener: fn => listeners.delete(fn)};
  return runInNewContext(source + '\n' +
    '({api: initStyleViaApi(), has: hasStyleViaAPI, send: sendStyleViaAPI})', {
    SAFARI: true, prefs: {__values: {disableAll: false}}, browser,
    chrome: {tabs: {onRemoved: event, onReplaced: event}},
    webNavigation: {onCommitted: event},
    isEmptyObj: obj => !Object.keys(obj).length,
    NOP() {}, updateIconBadge() {}, order: {prio: {}, main: {}},
    getSectionsByUrl: () => ({sections: [{id: 1, code: [code]}]}),
  });
}
documentAt(10);
let bg = background();
await bg.api.styleViaAPI.call({sender: {tab: {id: 10}, frameId: 0, url: 'https://example.com/'}},
  {method: 'styleApply'});
assert.equal(inserted.length, 1);

// New background, same page: reconnect without reinjecting duplicate CSS.
bg = background();
assert.equal(await bg.has(10, 0), true);
assert.equal(inserted.length, 1);
code = 'body { color: green }';
await bg.send(10, {method: 'styleUpdated', style: {id: 1, enabled: true}});
assert.equal(inserted.at(-1).css, code);
assert.equal(removed.at(-1).css, 'body { color: purple }');

// A second suspension must preserve the updated code, not the original code.
bg = background();
await bg.send(10, {method: 'styleUpdated', style: {id: 1, enabled: false}});
assert.equal(removed.at(-1).css, code);
bg = background();
assert.equal(await bg.has(10, 0), true, 'an unstyled but reachable page remains reachable');
const n = removed.length;
await bg.send(10, {method: 'styleDeleted', style: {id: 1}});
assert.equal(removed.length, n, 'disabled CSS must not reappear in a recovered snapshot');
assert.equal(await bg.has(999, 0), false, 'a missing or denied content script is not reachable');

// Recover subframes as well as the popup's top frame.
documentAt(10, 2);
await bg.api.styleViaAPI.call({sender: {tab: {id: 10}, frameId: 2, url: 'https://example.com/'}},
  {method: 'styleApply'});
bg = background();
await bg.send(10, {method: 'styleDeleted', style: {id: 1}});
assert.equal(removed.at(-1).target.frameIds[0], 2);

// Navigating creates a new content-script snapshot, so old CSS is never restored.
documentAt(10);
bg = background();
assert.equal(await bg.has(10, 0), true);
const beforeNavigationDelete = removed.length;
await bg.send(10, {method: 'styleDeleted', style: {id: 1}}, {frameId: 0});
assert.equal(removed.length, beforeNavigationDelete);
console.log('Safari lifecycle recovery tests passed');
