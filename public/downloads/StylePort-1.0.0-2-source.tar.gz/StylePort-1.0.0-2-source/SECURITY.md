# Security Policy

## Supported versions

Security fixes are provided for the latest published StylePort release. Users
should update to the newest version available through the official distribution
channel.

## Reporting a vulnerability

Please do not open a public issue for an unpatched vulnerability. Use GitHub's
private vulnerability reporting for the StylePort repository. Include the
affected version, impact, reproduction steps, and a minimal proof of concept if
it is safe to share.

Do not test against websites, accounts, or data you do not own or have explicit
permission to use. Reports will be acknowledged as soon as practical, and a
coordinated disclosure date will be agreed upon for validated issues.

## Scope

High-priority areas include unintended website access, execution outside a
style's declared URL scope, unsafe UserCSS parsing or compilation, extension
privilege escalation, and disclosure of locally stored styles or settings.
