# Attribution notice

StylePort is a downstream work based on
[Stylus](https://github.com/openstyles/stylus), the privacy-oriented UserCSS
manager maintained by the Stylus Team.

The upstream project is licensed under GPL-3.0-only. StylePort remains under the
same license, retains upstream Git history, and documents material downstream
changes. “StylePort” is the name of this downstream project and is not an
upstream Stylus release.
