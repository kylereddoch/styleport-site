# Contributing to StylePort

StylePort welcomes bug reports, compatibility findings, documentation fixes,
and focused code contributions. The current priority is a dependable,
privacy-first Safari UserCSS experience.

## Report an issue

Search the existing StylePort issues before opening a new one. A useful report
includes:

- macOS and Safari versions;
- StylePort version;
- a minimal UserCSS example when possible;
- the affected URL or a safe test page;
- exact reproduction steps and the result you expected;
- screenshots or console output with private information removed.

Do not include passwords, session cookies, private styles, or private URLs.
Security vulnerabilities should follow [SECURITY.md](SECURITY.md), not a public
issue.

## Development workflow

Requirements are Node.js 24 or newer, pnpm 11.8.0, and Xcode for Safari builds.

```sh
npx pnpm@11.8.0 install --frozen-lockfile
npx pnpm@11.8.0 test
npx pnpm@11.8.0 release-safari
```

Keep changes on a topic branch, preserve the upstream GPL attribution, and add
or update tests for behavior changes. Pull requests should explain the user
impact and list the validation performed.

Safari-specific behavior should stay behind capability checks or in the Safari
packaging layer so upstream engine updates remain practical.

## Upstream foundation

StylePort is based on the GPL-3.0-licensed
[Stylus](https://github.com/openstyles/stylus) project and retains its Git
history and contributor attribution. Bugs reproducible in unmodified Stylus may
also be relevant upstream, but StylePort-specific reports belong in the
StylePort repository.
