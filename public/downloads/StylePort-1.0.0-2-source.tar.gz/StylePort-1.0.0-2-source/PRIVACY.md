# StylePort Privacy Policy

Effective date: October 7, 2026

StylePort is a privacy-first UserCSS manager for Safari by Kyle Reddoch, under
the RelayByte brand. It has no advertising or user account system and does not
sell personal information. Styles and browsing history are not sent to the
developer or RevenueCat. Optional tips involve purchase processing as described
below.

## Data stored on your device

StylePort stores the styles you import or create, their settings, and extension
preferences in Safari's extension storage on your Mac. This information stays
on your device unless you choose to export a backup or otherwise share it.

Removing styles deletes them from StylePort. Removing the app and its extension
causes macOS and Safari to control deletion of the remaining local app data.

## Website access

Safari website access is required so StylePort can determine which user-selected
styles match a page and apply their compiled CSS. StylePort does not use this
access to build or transmit browsing history.

You control website access in Safari Settings and can restrict or revoke it at
any time. Revoking access prevents StylePort from styling those websites.

## Network requests you initiate

StylePort can retrieve a style when you provide its URL and can check an
installed style's update URL when you request or enable updates. Those requests
go to the host named by the style or URL. That host may receive ordinary network
information such as your IP address and user agent under its own privacy policy.

The Safari release does not inject marketplace installation hooks and does not
provide cloud synchronization.

## Optional tips

The App Store build offers optional, one-time tips through Apple's In-App
Purchase system and RevenueCat. Tips do not unlock features and are not
subscriptions. Every StylePort feature remains free.

RevenueCat is initialized when you open the tip jar. It processes an anonymous
app user identifier, purchase records, and related product, currency, and app
information to validate purchases and provide purchase reporting. StylePort
does not provide RevenueCat with your name, email address, styles, or browsing
history, and does not enable advertising identifier collection. Apple handles
payment information; StylePort and RevenueCat do not receive your card details.

Purchase history is disclosed for app functionality and purchase analytics,
not advertising tracking. An anonymous purchase record is not a StylePort
account. Deleting local app data does not itself delete purchase records held
by Apple or RevenueCat. Their policies govern their handling and retention of
that information:

- [Apple Privacy Policy](https://www.apple.com/legal/privacy/)
- [RevenueCat Privacy Policy](https://www.revenuecat.com/privacy/)

StylePort does not track users across other companies' apps or websites for
advertising. The App Store edition's privacy manifest declares purchase history
used for app functionality and analytics, with no tracking domains.

The direct-download edition does not include RevenueCat. Its support button
opens the StylePort website, where an optional contribution can be made through
Stripe. Opening the page does not initiate a payment. The website and payment
provider's privacy policies apply to that separate interaction.

## App updates for direct downloads

The direct-download edition uses Sparkle to check for and install signed app
updates. You can check manually and choose whether to enable automatic update
checks. Checks run while the companion app is open. The App Store edition uses
Apple's update system and does not include Sparkle.

Update checks contact the StylePort update host; downloads contact the host
listed in the signed update feed. These servers receive ordinary request
information, including an IP address and user-agent information identifying
the app and updater. Sparkle's optional system profiling is disabled. StylePort
does not include styles, browsing history, or RevenueCat purchase identifiers
in update requests. Hosting providers may retain ordinary server logs under
their own policies. Automatic installation is disabled; updates require user
interaction.

## Changes and contact

Material changes to this policy will be documented in the StylePort repository
and reflected by a new effective date. For privacy questions, use the
[StylePort support page](https://styleport.app/support/). Avoid including
sensitive information in public issue reports.
