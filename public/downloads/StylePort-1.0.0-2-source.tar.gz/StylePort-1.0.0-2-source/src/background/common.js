import {k_busy, kResolve} from '@/js/consts';
import {CHROME, FIREFOX} from '@/js/ua';
import {browserWindows} from '@/js/util-webext';

/** @type {Map<string,Promise>} */
export const clientDataJobs = __.MV3 && new Map();

/** Temporary storage for data needed elsewhere e.g. in a content script */
export const dataHub = Object.assign(new Map(), {
  pop(key) {
    const val = this.get(key);
    this.delete(key);
    return val;
  },
});

/** @type {Set<(isDark: boolean) => ?>} */
export const onSchemeChange = new Set();
/** @type {Set<(tabId: number, url: string, oldUrl?: string) => ?>} */
export const onTabUrlChange = new Set();
/** @type {Set<(tabId: number, frameId: number, port: chrome.runtime.Port) => ?>} */
export const onUnload = new Set();
/** @type {Set<(data: Object, type: 'committed'|'history'|'hash') => ?>} */
export const onUrlChange = new Set();

export const uuidIndex = Object.assign(new Map(), {
  custom: {},
  /** `obj` must have a unique `id`, a UUIDv4 `_id`, and Date.now() for `_rev`. */
  addCustom(obj, {get = () => obj, set}) {
    Object.defineProperty(uuidIndex.custom, obj._id, {get, set});
  },
});

// The Safari build is derived from Chrome MV3, but its UA has no Chromium
// version and Safari rejects even querying the Chromium-only permission.
export let WRB = __.B_CHROME ? CHROME ? null : false
  : __.B_FIREFOX || __.B_ANY && !!FIREFOX;
export let WRBTest = (__.B_CHROME ? !!CHROME : __.B_ANY && !!CHROME) &&
  browser.permissions.contains({permissions: ['webRequestBlocking']}).then(res => {
    WRBTest = null;
    WRB = res;
    return res;
  }).catch(() => {
    // Safari rejects queries for Chromium-only permission names.
    WRBTest = null;
    WRB = false;
    return false;
  });

/** Minimal init for a wake-up event */
export let bgPreInit = [];
export let bgInit = [];
export let bgBusy = global[k_busy] = (_ =>
  Object.assign(new Promise(cb => (_ = cb)), {[kResolve]: _})
)();

export let isVivaldi, vivaldiTest;
if ((__.B_CHROME || __.B_ANY && CHROME) && browserWindows) {
  vivaldiTest = (async (wnd = browserWindows.getLastFocused()) => (
    isVivaldi = !!((wnd = await wnd) && (wnd.vivExtData || wnd.extData))
  ));
} else {
  isVivaldi = false;
}

bgPreInit.push(WRBTest);
bgBusy.then(() => {
  bgBusy = bgPreInit = bgInit = null;
  delete global[k_busy];
});

if (__.DEBUG) {
  global._bgPreInit = bgPreInit;
  global._bgInit = bgInit;
  bgPreInit.push = (...args) => {
    const {stack} = new Error();
    for (const a of args) if (a && typeof a === 'object') a._stack = stack;
    return [].push.apply(bgPreInit, args);
  };
}
