import '@/js/browser';
import * as prefs from '@/js/prefs';
import {SAFARI} from '@/js/ua';
import {isEmptyObj, NOP} from '@/js/util';
import {webNavigation} from '@/js/util-webext';
import {updateIconBadge} from './icon-manager';
import {getSectionsByUrl} from './style-manager';
import {order} from './style-manager/util';

let bridge;

export function hasStyleViaAPI(tabId, frameId = 0) {
  return bridge?.has(tabId, frameId) || false;
}

export function sendStyleViaAPI(tabId, data, options) {
  return bridge?.send(tabId, data, options);
}

/**
 * Uses chrome.tabs.insertCSS or chrome.scripting.insertCSS in Safari.
 */
export default function initStyleViaApi() {
  const ACTIONS = {
    styleApply,
    styleDeleted,
    styleUpdated,
    styleAdded,
    urlChanged,
    injectorConfig,
    updateCount,
  };
  const onError = NOP;
  const calcOrder = ({id}) =>
    (order.prio[id] || 0) * 1e6 ||
    order.main[id] ||
    id + .5e6;
  /* <tabId>: Object
       <frameId>: Object
         url: String, non-enumerable
         <styleId>: Array of strings
           section code */
  const cache = new Map();
  const reachable = new Map();
  let observingTabs = false;

  bridge = {
    has(tabId, frameId) {
      return SAFARI ? restoreFrame(tabId, frameId) : reachable.get(tabId)?.has(frameId);
    },
    async send(tabId, data, options) {
      if (SAFARI) {
        const frames = options?.frameId != null ? [{frameId: options.frameId}]
          : await browser.webNavigation.getAllFrames({tabId}).catch(() => [{frameId: 0}]);
        await Promise.all(frames.map(({frameId}) => restoreFrame(tabId, frameId)));
      }
      const tabFrames = reachable.get(tabId);
      if (!tabFrames) return;
      const requests = Array.isArray(data) ? data : [data];
      const frameIds = options?.frameId != null
        ? [options.frameId]
        : [...tabFrames.keys()];
      let handled;
      for (const frameId of frameIds) {
        const url = tabFrames.get(frameId);
        if (url == null) continue;
        const sender = {tab: {id: tabId}, frameId, url};
        for (const request of requests) {
          const fn = ACTIONS[request?.method];
          if (fn) {
            await fn(request, sender);
            handled = true;
          }
        }
        if (SAFARI) await checkpointFrame(tabId, frameId);
      }
      maybeToggleObserver();
      return handled;
    },
  };

  return /** @namespace API */ {
    async styleViaAPI(request) {
      try {
        if (SAFARI) await restoreFrame(this.sender.tab.id, this.sender.frameId);
        rememberFrame(this.sender);
        const fn = ACTIONS[request.method];
        if (fn) await fn(request, this.sender);
        if (SAFARI) await checkpointFrame(this.sender.tab.id, this.sender.frameId);
      } finally {
        maybeToggleObserver();
      }
    },
  };

  function updateCount(request, sender) {
    const {tab, frameId} = sender;
    if (frameId) {
      return; // Subframes still need to finish applying/checkpointing their CSS.
    }
    const {frameStyles} = getCachedData(tab.id, frameId);
    updateIconBadge.call({sender}, Object.keys(frameStyles));
  }

  async function styleApply({id = null, ignoreUrlCheck = false}, sender) {
    if (prefs.__values['disableAll']) {
      return;
    }
    const {tab, frameId, url} = sender;
    const {tabFrames, frameStyles} = getCachedData(tab.id, frameId);
    if (id === null && !ignoreUrlCheck && frameStyles.url === url) {
      return;
    }
    const {sections} = getSectionsByUrl.call({sender}, url, {id});
    const tasks = [];
    for (const sec of sections.sort((a, b) => calcOrder(a) - calcOrder(b))) {
      const styleId = sec.id;
      const code = sec.code.join('\n');
      if (code === (frameStyles[styleId] || []).join('\n')) {
        continue;
      }
      frameStyles[styleId] = sec.code;
      tasks.push(insertCSS(tab.id, frameId, code).catch(onError));
    }
    if (!removeFrameIfEmpty(tab.id, frameId, tabFrames, frameStyles)) {
      Object.defineProperty(frameStyles, 'url', {value: url, configurable: true});
      tabFrames[frameId] = frameStyles;
      cache.set(tab.id, tabFrames);
    }
    await Promise.all(tasks);
    return updateCount(null, {tab, frameId});
  }

  async function styleDeleted({style: {id}}, {tab, frameId}) {
    const {tabFrames, frameStyles, styleSections} = getCachedData(tab.id, frameId, id);
    const code = styleSections.join('\n');
    if (code && !duplicateCodeExists({frameStyles, id, code})) {
      delete frameStyles[id];
      removeFrameIfEmpty(tab.id, frameId, tabFrames, frameStyles);
      await removeCSS(tab.id, frameId, code);
      updateCount(null, {tab, frameId});
    }
  }

  async function styleUpdated({style}, sender) {
    if (!style.enabled) {
      return styleDeleted({style}, sender);
    }
    const {tab, frameId} = sender;
    const {frameStyles, styleSections} = getCachedData(tab.id, frameId, style.id);
    const code = styleSections.join('\n');
    await styleApply(style, sender);
    if (code && !duplicateCodeExists({frameStyles, code, id: null})) {
      await removeCSS(tab.id, frameId, code);
    }
  }

  function styleAdded({style}, sender) {
    if (style.enabled) return styleApply(style, sender);
  }

  async function urlChanged(request, sender) {
    const {tab, frameId} = sender;
    const oldStylesCode = getFrameStylesJoined(sender);
    await styleApply({ignoreUrlCheck: true}, sender);
    const newStylesCode = getFrameStylesJoined(sender);
    return Promise.all(oldStylesCode
      .map(code => !newStylesCode.includes(code) && removeCSS(tab.id, frameId, code))
      .filter(Boolean));
  }

  async function injectorConfig({cfg: {off}}, sender) {
    if (off) {
      const {tab, frameId} = sender;
      const {tabFrames, frameStyles} = getCachedData(tab.id, frameId);
      if (!isEmptyObj(frameStyles)) {
        removeFrameIfEmpty(tab.id, frameId, tabFrames, {});
        await Promise.all(Object.keys(frameStyles).map(id =>
          removeCSS(tab.id, frameId, frameStyles[id].join('\n'))));
      }
    } else if (off != null) {
      return styleApply({}, sender);
    }
  }

  /* utilities */

  // Safari unloads its background page while content scripts and inserted CSS
  // survive. Keep the exact applied CSS in the document's isolated content
  // script, so a new background can remove/update it without reloading the page.
  // This avoids persisting browsing URLs or duplicating large CSS in storage.
  async function restoreFrame(tabId, frameId) {
    if (reachable.get(tabId)?.has(frameId)) return true;
    const res = await browser.tabs.sendMessage(tabId, {
      data: {method: 'apiStyleState'},
    }, {frameId}).catch(NOP);
    const state = res?.data;
    if (!state || typeof state.url !== 'string' || !state.styles) return false;
    const {tabFrames} = getCachedData(tabId, frameId);
    const frameStyles = state.styles;
    if (!isEmptyObj(frameStyles)) {
      Object.defineProperty(frameStyles, 'url', {value: state.url, configurable: true});
      tabFrames[frameId] = frameStyles;
      cache.set(tabId, tabFrames);
    }
    rememberFrame({tab: {id: tabId}, frameId, url: state.url});
    maybeToggleObserver();
    return true;
  }

  function checkpointFrame(tabId, frameId) {
    return browser.tabs.sendMessage(tabId, {
      data: {method: 'apiStyleState', styles: getCachedData(tabId, frameId).frameStyles},
    }, {frameId}).catch(NOP);
  }

  function maybeToggleObserver() {
    let method;
    if (!observingTabs && reachable.size) {
      method = 'addListener';
    } else if (observingTabs && !reachable.size) {
      method = 'removeListener';
    } else {
      return;
    }
    observingTabs = !observingTabs;
    webNavigation.onCommitted[method](onNavigationCommitted);
    chrome.tabs.onRemoved[method](onTabRemoved);
    chrome.tabs.onReplaced[method](onTabReplaced);
  }

  function onNavigationCommitted({tabId, frameId}) {
    if (frameId === 0) {
      onTabRemoved(tabId);
      return;
    }
    const reachableFrames = reachable.get(tabId);
    if (reachableFrames?.delete(frameId) && !reachableFrames.size) {
      reachable.delete(tabId);
    }
    const tabFrames = cache.get(tabId);
    if (tabFrames && frameId in tabFrames) {
      delete tabFrames[frameId];
      if (isEmptyObj(tabFrames)) {
        onTabRemoved(tabId);
      }
    }
  }

  function onTabRemoved(tabId) {
    cache.delete(tabId);
    reachable.delete(tabId);
    maybeToggleObserver();
  }

  function onTabReplaced(addedTabId, removedTabId) {
    onTabRemoved(removedTabId);
  }

  function removeFrameIfEmpty(tabId, frameId, tabFrames, frameStyles) {
    if (isEmptyObj(frameStyles)) {
      delete tabFrames[frameId];
      if (isEmptyObj(tabFrames)) {
        cache.delete(tabId);
      }
      return true;
    }
  }

  function getCachedData(tabId, frameId, styleId) {
    const tabFrames = cache.get(tabId) || {};
    const frameStyles = tabFrames[frameId] || {};
    const styleSections = styleId && frameStyles[styleId] || [];
    return {tabFrames, frameStyles, styleSections};
  }

  function rememberFrame({tab, frameId, url}) {
    let frames = reachable.get(tab.id);
    if (!frames) reachable.set(tab.id, frames = new Map());
    frames.set(frameId, url);
  }

  function getFrameStylesJoined({
    tab,
    frameId,
    frameStyles = getCachedData(tab.id, frameId).frameStyles,
  }) {
    return Object.keys(frameStyles).map(id => frameStyles[id].join('\n'));
  }

  function duplicateCodeExists({
    tab,
    frameId,
    frameStyles = getCachedData(tab.id, frameId).frameStyles,
    frameStylesCode = {},
    id,
    code = frameStylesCode[id] || frameStyles[id].join('\n'),
  }) {
    id = String(id);
    for (const styleId in frameStyles) {
      if (id !== styleId &&
          code === (frameStylesCode[styleId] || frameStyles[styleId].join('\n'))) {
        return true;
      }
    }
  }

  function removeCSS(tabId, frameId, code) {
    if (SAFARI) {
      return browser.scripting.removeCSS({
        css: code,
        target: makeTarget(tabId, frameId),
      }).catch(onError);
    }
    return browser.tabs.removeCSS(tabId, {frameId, code, matchAboutBlank: true})
      .catch(onError);
  }

  function insertCSS(tabId, frameId, code) {
    if (SAFARI) {
      return browser.scripting.insertCSS({
        css: code,
        target: makeTarget(tabId, frameId),
      });
    }
    return browser.tabs.insertCSS(tabId, {
      code,
      frameId,
      runAt: 'document_start',
      matchAboutBlank: true,
    });
  }

  function makeTarget(tabId, frameId) {
    return frameId ? {tabId, frameIds: [frameId]} : {tabId};
  }
}
