import '@/js/dom-init';
import {API} from '@/js/msg-api';
import {getMetaComment} from '@/js/style-util';
import './import.css';

const panels = $$('[data-panel]');
const modeButtons = $$('.import-modes [data-mode]');
const fileInput = $id('style-file');
const dropzone = $('.file-drop');
const status = $id('import-status');

for (const button of modeButtons) {
  button.onclick = () => selectMode(button.dataset.mode);
}

fileInput.onchange = () => importFile(fileInput.files[0]);
Object.assign(dropzone, {
  ondragover(event) {
    if (!event.dataTransfer.types.includes('Files')) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = 'copy';
    dropzone.classList.add('dragging');
  },
  ondragleave() {
    dropzone.classList.remove('dragging');
  },
  ondrop(event) {
    event.preventDefault();
    dropzone.classList.remove('dragging');
    importFile(event.dataTransfer.files[0]);
  },
});

$('[data-panel="url"]').onsubmit = async event => {
  event.preventDefault();
  await run(async () => {
    const updateUrl = new URL($id('style-url').value).href;
    if (!/^https?:/.test(updateUrl)) throw new Error('Enter an http or https style URL.');
    const sourceCode = await API.download(updateUrl);
    const normalized = normalize(sourceCode, nameFromUrl(updateUrl));
    await API.usercss.openInstaller({
      sourceCode: normalized.code,
      updateUrl: normalized.usercss ? updateUrl : null,
    });
  });
};

$('[data-panel="paste"]').onsubmit = async event => {
  event.preventDefault();
  await run(async () => {
    const normalized = normalize($id('style-code').value, $id('style-name').value);
    await API.usercss.openInstaller({sourceCode: normalized.code});
  });
};

function selectMode(mode) {
  for (const button of modeButtons) {
    const active = button.dataset.mode === mode;
    button.setAttribute('aria-selected', `${active}`);
    button.tabIndex = active ? 0 : -1;
  }
  for (const panel of panels) panel.hidden = panel.dataset.panel !== mode;
  status.textContent = '';
}

async function importFile(file) {
  if (!file) return;
  await run(async () => {
    if (!/\.(?:user\.)?css$/i.test(file.name)) {
      throw new Error('Choose a .css or .user.css file.');
    }
    const normalized = normalize(await file.text(), file.name.replace(/(?:\.user)?\.css$/i, ''));
    await API.usercss.openInstaller({sourceCode: normalized.code});
  });
  fileInput.value = '';
}

async function run(task) {
  const controls = $$('button, input, textarea');
  controls.forEach(el => (el.disabled = true));
  status.className = 'working';
  status.textContent = 'Preparing a safe preview…';
  try {
    await task();
    status.className = 'success';
    status.textContent = 'Preview opened in a new tab. Review the style, then choose Install.';
  } catch (error) {
    status.className = 'error';
    status.textContent = error.message || `${error}`;
  } finally {
    controls.forEach(el => (el.disabled = false));
  }
}

function normalize(sourceCode, suggestedName = '') {
  const code = `${sourceCode || ''}`.trim();
  if (!code) throw new Error('The style is empty.');
  if (getMetaComment(code, '?')) return {code, usercss: true};
  const name = (suggestedName || 'Imported Style')
    .replace(/[\r\n*]+/g, ' ')
    .trim() || 'Imported Style';
  const meta = [
    '/* ==UserStyle==',
    `@name           ${name}`,
    `@namespace      styleport.local/${slugify(name)}`,
    '@version        1.0.0',
    '@description    Imported locally with StylePort',
    '==/UserStyle== */',
  ].join('\n');
  return {
    usercss: false,
    code: `${meta}\n\n${code}\n`,
  };
}

function slugify(name) {
  return name.toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '') || 'imported';
}

function nameFromUrl(url) {
  const path = new URL(url).pathname;
  return decodeURIComponent(path.split('/').pop() || '')
    .replace(/(?:\.user)?\.css$/i, '') || 'Imported Style';
}
