// TODO: find out why terser doesn't drop these vars in ./get-client-data.js
const uad = navigator.userAgentData;
const ua = uad || navigator.userAgent;
const brands = uad ? /*@__PURE__*/ uad.brands.map(_ => `${_.brand}/${_.version}`).join(' ') : ua;
// TODO: remove navigator.platform when minimum_chrome_version >= 93
const platform = uad ? uad.platform || navigator.platform : ua;
const chromeVer = /*@__PURE__*/ +brands.match(/Chrom\w*\/(\d+)|$/)[1];
export const CHROME = chromeVer;
export const FIREFOX = chromeVer ? NaN : /*@__PURE__*/ +brands.match(/Firefox\w*\/(\d+)|$/)[1];
export const SAFARI = !chromeVer && !FIREFOX && /*@__PURE__*/ /Safari\//.test(brands);
export const OPERA = /*@__PURE__*/ +brands.match(/(?:Opera|OPR)\w*\/(\d+)|$/)[1];
export const MAC = /*@__PURE__*/ /mac/i.test(platform);
export const MOBILE = uad ? uad.mobile : /*@__PURE__*/ /Android/.test(ua);
export const WINDOWS = /*@__PURE__*/ /Windows/.test(platform);
export const VIVALDI = /*@__PURE__*/ +brands.match(/Vivaldi\w*\/(\d+)|$/)[1];
