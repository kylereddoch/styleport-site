// WebKit rejects lock requests and queries when their document is destroyed or
// enters the back/forward cache. This is normal teardown, not a failed style
// operation. Use only on Web Locks promises, never as a global error filter.
export function handleWebLockError(error) {
  if (error?.name !== 'AbortError' ||
      error.message !== 'Promise was rejected because the browsing context is going away') {
    throw error;
  }
}
