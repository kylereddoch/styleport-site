# StylePort roadmap

## Milestone 1 — Safari foundation

- Package the mature UserCSS engine as a macOS Safari Web Extension.
- Apply plain CSS and UserCSS at `document_start` without flashing.
- Import remote and local styles.
- Configure `text`, `color`, `checkbox`, `select`, `dropdown`, `range`,
  `number`, and `image` variables.
- Compile default, USO, Less, and Stylus preprocessors.
- Enable, disable, edit, delete, reorder, export, and update styles.
- Test injection, navigation, frames, and variable recompilation in Safari.

## Milestone 2 — Safari product experience

- Replace inherited branding and icons with the StylePort design system.
- Simplify the manager and popup for Safari conventions.
- Add clear website-permission diagnostics.
- Add an injection health check that distinguishes matching from successful
  application.
- Disable or replace APIs that Safari does not implement.
- Add migration from Stylus-compatible backups.

## Milestone 3 — Distribution and devices

- Sign and submit the macOS release when an Apple Developer team is available.
- Add an iOS/iPadOS container and device-specific manager layout.
- Publish reproducible builds and public support/privacy URLs.
- Validate shared builds for Chromium and Firefox.

## Definition of reliable

A style is not reported as active merely because its URL matches. StylePort must
verify that its content script is reachable and has acknowledged the current
compiled style revision. The popup will surface permission, compilation, and
injection failures separately.
