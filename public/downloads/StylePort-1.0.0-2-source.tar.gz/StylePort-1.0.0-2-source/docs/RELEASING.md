# Safari release process

StylePort's release artifacts are the macOS container app and its embedded
Safari Web Extension. Version 1.0.0 targets macOS 14 or newer.

## Release checks

1. Use the current public Xcode release from the Mac App Store. Beta Xcode
   archives are for development testing only and must not be published.
2. Install the locked dependencies with Node.js 24 or newer.
3. Run `npx pnpm@11.8.0 test`.
4. Run `npx pnpm@11.8.0 release-safari`.
5. Build both Debug and Release configurations in Xcode.
6. Verify the app and embedded extension signatures.
7. Test import from file, URL, and pasted CSS; enable/disable; variable changes;
   edit; backup restore/export; updates; and website-permission failures.
8. Test a representative style on the current public Safari release and compare
   computed styles and layout with a known-good browser implementation.
9. Archive in Xcode and use the appropriate App Store or Developer ID workflow
   below; do not mix the two distribution artifacts.

## Local signed build

For a release-configuration build that Safari can register for local testing,
run `npx pnpm@11.8.0 build-safari-app-local` after `release-safari`. This uses
Xcode's ad hoc “Sign to Run Locally” identity and preserves the sandbox
entitlements Safari needs to recognize the embedded extension. The app is
written to `.build/safari-release-signed/Build/Products/Release/StylePort.app`.

Do not use `CODE_SIGNING_ALLOWED=NO` for an interactive Safari test build: the
result can be inspected and compiled, but it does not contain the generated
extension entitlements required for Safari registration.

## Direct website distribution

The direct edition uses Developer ID Application signing and Sparkle 2.10.0.
The App Store project remains RevenueCat-only and does not link Sparkle.
`tools/prepare-direct.mjs` generates a sibling `StylePortDirect.xcodeproj`
from the primary project, sharing app sources and Safari resources while
substituting the direct support handler, privacy manifest, and updater settings.
The generated project is ignored; its generator and package lock are tracked.
Do not edit the generated project by hand.

Run `release-safari` first, then use a new archive/output path for each candidate:

```sh
export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
export STYLEPORT_ARCHIVE="$PWD/.build/StylePort-direct.xcarchive"
export STYLEPORT_OUTPUT="$PWD/.build/direct-release"
node tools/direct-release.mjs archive
node tools/test-direct.mjs
node tools/direct-release.mjs notarize
node tools/direct-release.mjs export
node tools/direct-release.mjs package
node tools/package-source.mjs "$STYLEPORT_OUTPUT/website"
```

`notarize` uses the Apple account already signed into Xcode. Upload success is
not approval. `export` succeeds only when Apple's notarization is available;
it then checks the stapled ticket, signature, and Gatekeeper assessment.
If Apple is still processing, rerun `export` after processing completes.
An Apple Development, Mac Distribution, or ad hoc signature is not a direct
release signature. The archive command unregisters its temporary extension
copy without touching the installed `/Applications/StylePort.app`.

### Sparkle signing and hosting

Use the official Sparkle 2.10.0 tools, with `SPARKLE_BIN` pointing to their `bin`
directory (default `.build/sparkle-tools/bin`). The app-specific Ed25519 key
is stored in the login Keychain under account `dev.relaybyte.styleport`.
Only the public key belongs in the repository. Back up the private key securely;
never paste it into chat, commit it, or put it in website assets. Changing or
losing this key can interrupt the update chain.

The package command creates a ZIP, SHA-256 checksum, and signed appcast locally.
It requires release notes at `docs/releases/<version>-<build>.html`, signs them,
and places their canonical website URL in the re-signed appcast. The source
packager snapshots an explicit allowlist of sources, build scripts, locks and
licenses; it excludes local backups, credentials and Xcode user state. Review
the snapshot and source checksums before approving publication.
It never installs the app or publishes anything. After release approval:

- Host the unchanged signed appcast at `https://styleport.app/updates/appcast.xml`.
- Host the exact ZIP and checksum under `https://styleport.app/downloads/`.
- Publish release notes, the corresponding GPL source, and the updated privacy
  policy alongside the release. Preserve upstream attribution and licenses.
- Do not edit a signed appcast after generation; regenerate it to re-sign.
- For later releases, retain the existing feed and archives in the website
  staging directory before generating the next feed. Increase CFBundleVersion.
- Verify the hosted bytes and signatures, then test an older signed direct
  build updating to the candidate with Safari enabled and styles backed up.

Sparkle asks before enabling automatic checks; system profiling and automatic
installation are disabled by default. Users can check manually from the
companion app's StylePort menu or its setup page, and toggle automatic checks
in the StylePort menu. Automatic checks run while that app is open,
not continuously from the Safari extension. The app requires signed feeds and
verifies update signatures before extraction. The direct edition opens the
website for optional support instead of using RevenueCat purchases.

Both editions retain the same app and extension identifiers. They are alternate
distributions, not apps intended to run side by side. Export a backup before
switching editions, and obtain action-time permission before installation or
enabling the extension. Website publication and an end-to-end signed update
test are separate gates from successful notarization.

References: [Sparkle sandbox integration](https://sparkle-project.org/documentation/sandboxing/)
and [publishing signed updates](https://sparkle-project.org/documentation/publishing/).

## TestFlight and App Store distribution

The current App Store availability settings exclude all 27 European Union
storefronts, including consumable tips, and automatic availability in future
territories is off. Those settings remain unchanged pending the owner's
distribution decision. Non-trader status does not itself prohibit EU
distribution. Do not change the account's legal declaration as part of a
release. The public TestFlight group is open to anyone after beta approval;
App Store territory settings are not a geographic filter for that public link.

Before submission, provide the public privacy-policy URL, support URL,
screenshots, app description, age rating, and App Privacy answers. The answers
must agree with `PRIVACY.md` and `PrivacyInfo.xcprivacy`. Grant only the website
access needed for the extension's core purpose.

### Optional tips

The macOS container uses RevenueCat's Apple SDK, with the `tips` offering and
five consumable packages. Tips unlock no features and require no entitlements.
Preserve the existing small-tip identifier `com.kylereddoch.StylePort.tip.199`;
the remaining identifiers use `dev.relaybyte.styleport.tip.*`.

Before calling billing ready, verify all five localized prices in the running
app, a sandbox purchase and repeat purchase, cancellation, pending/error states,
and the matching transaction in RevenueCat. Capture the actual tip window for
Apple's IAP review screenshots. A successful build or valid credentials alone
is not end-to-end purchase validation. App Privacy and the published privacy
policy must disclose the optional RevenueCat purchase processing.

### Sandbox tester setup

Use a dedicated Sandbox Apple Account for purchases in development-signed
builds. Developer team membership does not create one automatically.
TestFlight can use a normal Apple Account while processing purchases in the
sandbox; that differs from this local development-build workflow.

1. Open App Store Connect > Users and Access > Sandbox > Add Test Account.
2. Enter the tester's name and an email address you control that has never
   been registered as an Apple Account or used for App Store purchases.
3. Select United States for the initial StylePort test. This does not change
   app availability or authorize EU distribution.
4. The account owner enters and confirms a unique password and submits Create.
   Save the login privately in a password manager, with a descriptive title
   such as `RelayByte Apple Sandbox US`. Never store it in this repository,
   screenshots, test logs, or chat. Apple does not allow editing the tester's
   name, email, or password after creation.
5. Verify that the tester appears in the Sandbox list. On the Mac, use the
   Mac App Store's Settings/Preferences > Sandbox Account controls to sign in
   for testing. Do not replace the Mac's main iCloud account. If the sandbox
   control is not available, initiate a purchase in the development app and
   inspect Apple's sign-in prompt before proceeding.

The tester is managed at the developer-account level, not as a StylePort
RevenueCat entitlement. It can be reused for the developer's other apps;
verify each app's products and transactions separately. Additional testers
are useful for isolated histories and different storefronts.

For StylePort, confirm Apple's purchase sheet explicitly identifies Sandbox
and says no charge will occur. Complete Small Tip twice and verify two
distinct sandbox transactions for `com.kylereddoch.StylePort.tip.199` in
RevenueCat with sandbox data visible. Both purchases must finish successfully,
the controls must become usable again, and no feature entitlement should be
required. Record cancellation, failure, and pending behavior separately.
An account appearing in the tester list is not proof that purchases work.

Setup status on October 7, 2026: App Store Connect lists one sandbox tester,
Kyle Reddoch, with United States selected. Account creation is verified.
The Mac App Store had the regular Apple Account selected as its Sandbox
Account; that sandbox session was signed out without signing out the main
App Store account. The new tester's sandbox sign-in is verified. StylePort
displayed its successful-purchase thank-you message and reenabled the tip
buttons. RevenueCat recorded two USD 1.99 Small Tip purchases from the `tips`
offering, at 6:30 and 6:31 p.m. America/Chicago, with Sandbox data enabled.
Both use `com.kylereddoch.StylePort.tip.199`; the customer profile shows
`Purchased 2x` and no feature entitlement, as intended. Initial and repeat
purchase verification pass; pending and other failure scenarios remain.
Keep the tester email and password in the private password-manager record
rather than this public repository.

References: [Apple sandbox account setup](https://developer.apple.com/help/app-store-connect/test-in-app-purchases/create-a-sandbox-apple-account/)
and [RevenueCat Apple sandbox testing](https://www.revenuecat.com/docs/test-and-launch/sandbox/apple-app-store).

## Credentials and signing

The Xcode project records the public StylePort team identifier so automatic
signing selects the correct team. The repository contains no signing private
key, certificate file, App Store Connect credential, or notarization secret.
Unsigned, ad hoc, and Apple Development builds are for local validation only
and must not be distributed as a public release.

## Versioning

Keep these values synchronized:

- `package.json` version;
- `src/manifest.json` version;
- `MARKETING_VERSION` for both Xcode targets.

Increment `CURRENT_PROJECT_VERSION` for every uploaded build, including rebuilds
of the same marketing version.
