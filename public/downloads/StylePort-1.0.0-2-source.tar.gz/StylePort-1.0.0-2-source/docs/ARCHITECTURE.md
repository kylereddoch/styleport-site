# Architecture

StylePort uses a browser-neutral WebExtension core and a thin native Safari
container.

## Extension layers

1. **UserCSS ingestion** parses metadata, variables, update URLs, and style
   source.
2. **Compilation** resolves configured variables and invokes the default, USO,
   Less, or Stylus compiler.
3. **Matching** evaluates standard URL rules and `@-moz-document` sections.
4. **Persistence** stores styles, revisions, preferences, and update metadata in
   the extension database.
5. **Injection** applies compiled sections from a document-start content script.
6. **Management UI** provides installation, editing, configuration, backup, and
   update workflows.

## Safari adaptation

`tools/build-safari.mjs` creates `dist-safari/` from the shared Manifest V3
build and removes Chrome-only manifest capabilities. The Xcode project in
`safari/` packages those resources as a macOS app and Safari extension.

Safari-specific work belongs behind capability checks or in small adapters so
the shared UserCSS engine remains portable.

## Upstream relationship

The upstream Stylus remote is retained as `upstream`. StylePort changes should
stay focused and documented so security and compatibility fixes can continue to
be incorporated from upstream.
