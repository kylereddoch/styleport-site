# RelayByte application naming convention

Adopted October 7, 2026 for new apps and services. RelayByte is the product
brand; Kyle Reddoch remains the legal developer and seller. Names do not
imply a separate company or DBA.

## Stable identifiers

Use `dev.relaybyte.<app>` as the root bundle identifier. The app slug is
lowercase ASCII letters and digits, starts with a letter, and has no spaces
or punctuation. Choose it before registering products or uploading builds.
Display names can use normal branding and capitalization independently.

| Component | Convention | StylePort example |
| --- | --- | --- |
| Main app | `dev.relaybyte.<app>` | `dev.relaybyte.styleport` |
| Safari extension | `<root>.safari` | `dev.relaybyte.styleport.safari` |
| Other extension/helper | `<root>.<purpose>` | `dev.relaybyte.styleport.helper` |
| Unit tests | `<root>.tests` | `dev.relaybyte.styleport.tests` |
| UI tests | `<root>.uitests` | `dev.relaybyte.styleport.uitests` |
| App group, if needed | `group.<root>` | `group.dev.relaybyte.styleport` |
| App Store SKU | `<app>-<platform>` | `styleport-macos` |
| Tip product | `<root>.tip.<tier>` | `dev.relaybyte.styleport.tip.small` |
| One-time feature product | `<root>.unlock.<feature>` | `dev.relaybyte.example.unlock.pro` |
| Subscription product | `<root>.subscription.<tier>.<period>` | `dev.relaybyte.example.subscription.pro.annual` |

Use semantic product tiers rather than prices in identifiers: prices can
change and are localized. StylePort's initial tip tiers are small ($1.99),
medium ($2.99), large ($4.99), generous ($5.99), and outstanding ($9.99), with
USD as the base storefront currency. Display actual prices returned by Apple.

StylePort preserves its existing small-tip Apple product ID,
`com.kylereddoch.StylePort.tip.199`, as a legacy exception. The app and RevenueCat
must use that exact ID for `tip_small`; do not create a duplicate merely to
change its prefix. The other four tip products use the convention above.

Do not add version numbers or distribution channels to identifiers by default.
Use separate IDs for separate installed apps only when explicitly intended;
decide direct-download/App Store identity and data boundaries before release.

## RevenueCat and repositories

- RevenueCat project: the public app name, e.g. `StylePort`.
- RevenueCat Apple app: `<App> (App Store)`.
- RevenueCat offerings: lowercase purpose, e.g. `tips`.
- RevenueCat tip packages: `tip_small`, `tip_medium`, `tip_large`,
  `tip_generous`, `tip_outstanding`. No feature entitlement for optional tips.
- Product IDs in RevenueCat must exactly match their App Store Connect IDs.
- New repositories: lowercase kebab-case, e.g. `styleport`, `styleport-site`.
- Keep websites in separate repositories when requested; do not rename an
  existing repository or deployment merely for cosmetic consistency.

## Migration and release safety

Never rename an uploaded app's bundle ID for consistency. Preserve existing
identities for Trayage and Dwellmo. For a pre-upload change, update the main
app, embedded extensions, runtime lookup strings, Apple registrations,
provisioning, App Store Connect, RevenueCat, and tests together.

An identifier change creates a new local app/extension identity. Existing
Safari permissions and local style storage may not carry over. Export styles
before installing the renamed build; keep the old copy until import and
validation succeed. Installation/enabling requires the user's confirmation.

Do not delete legacy Apple identifiers or purchase drafts without approval.
Do not create products, upload builds, or publish until the intended identity
has been checked against this convention.
