import Cocoa

// The direct-download edition does not link StoreKit or RevenueCat.
// Opening this page never initiates a payment.
final class TipJarController {
    static let shared = TipJarController()

    func present() {
        NSWorkspace.shared.open(URL(string: "https://styleport.app/#pricing")!)
    }
}
