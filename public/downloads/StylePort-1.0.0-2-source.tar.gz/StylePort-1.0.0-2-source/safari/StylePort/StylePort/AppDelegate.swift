//
//  AppDelegate.swift
//  StylePort
//
//  Created by CybersecKyle on 7/15/26.
//

import Cocoa
#if STYLEPORT_DIRECT
import Sparkle
#endif

@main
class AppDelegate: NSObject, NSApplicationDelegate, NSMenuItemValidation {
#if STYLEPORT_DIRECT
    private var updaterController: SPUStandardUpdaterController?
#endif

    func applicationDidFinishLaunching(_ notification: Notification) {
#if STYLEPORT_DIRECT
        let updater = SPUStandardUpdaterController(startingUpdater: true,
                                                  updaterDelegate: nil,
                                                  userDriverDelegate: nil)
        updaterController = updater
        if let appMenu = NSApp.mainMenu?.items.first?.submenu {
            let item = NSMenuItem(title: "Check for Updates…",
                                 action: #selector(SPUStandardUpdaterController.checkForUpdates(_:)),
                                 keyEquivalent: "")
            item.target = updater
            appMenu.insertItem(item, at: min(2, appMenu.items.count))
            let automatic = NSMenuItem(title: "Automatically Check for Updates",
                                       action: #selector(toggleAutomaticUpdates(_:)),
                                       keyEquivalent: "")
            automatic.target = self
            automatic.toolTip = "Check for updates while the StylePort app is open."
            appMenu.insertItem(automatic, at: min(3, appMenu.items.count))
        }
#endif
        // Load the bundled artwork directly so the running Dock tile does not
        // retain an older Launch Services icon after an in-place app update.
        if let iconURL = Bundle.main.url(forResource: "AppIcon", withExtension: "icns"),
           let icon = NSImage(contentsOf: iconURL) {
            NSApplication.shared.applicationIconImage = icon
        }
        if let help = NSApplication.shared.helpMenu {
            help.removeAllItems()
            let support = help.addItem(withTitle: "StylePort Help", action: #selector(openSupport), keyEquivalent: "?")
            support.target = self
            let privacy = help.addItem(withTitle: "Privacy Policy", action: #selector(openPrivacy), keyEquivalent: "")
            privacy.target = self
            help.addItem(.separator())
            let tips = help.addItem(withTitle: "Support StylePort…", action: #selector(openTipJar), keyEquivalent: "")
            tips.target = self
        }
    }

    @objc private func openSupport() {
        NSWorkspace.shared.open(URL(string: "https://styleport.app/support/")!)
    }

    @objc private func openPrivacy() {
        NSWorkspace.shared.open(URL(string: "https://styleport.app/privacy/")!)
    }

    @objc private func openTipJar() {
        TipJarController.shared.present()
    }

#if STYLEPORT_DIRECT
    func checkForUpdates() {
        updaterController?.checkForUpdates(nil)
    }

    @objc private func toggleAutomaticUpdates(_ sender: NSMenuItem) {
        guard let updater = updaterController?.updater else { return }
        updater.automaticallyChecksForUpdates.toggle()
        sender.state = updater.automaticallyChecksForUpdates ? .on : .off
    }
#endif

    func validateMenuItem(_ menuItem: NSMenuItem) -> Bool {
#if STYLEPORT_DIRECT
        if menuItem.action == #selector(toggleAutomaticUpdates(_:)) {
            menuItem.state = updaterController?.updater.automaticallyChecksForUpdates == true ? .on : .off
            return updaterController != nil
        }
#endif
        return true
    }

    func application(_ application: NSApplication, open urls: [URL]) {
        // A link can only display the jar; purchases still require an explicit
        // choice in the native window and Apple's purchase confirmation.
        guard urls.contains(where: { $0.absoluteString == "styleport://tips" }) else { return }
        TipJarController.shared.present()
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        return true
    }

}
