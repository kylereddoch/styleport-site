//
//  ViewController.swift
//  StylePort
//
//  Created by CybersecKyle on 7/15/26.
//

import Cocoa
import SafariServices
import WebKit

let extensionBundleIdentifier = "dev.relaybyte.styleport.safari"

class ViewController: NSViewController, WKNavigationDelegate, WKScriptMessageHandler {

    @IBOutlet var webView: WKWebView!

    override func viewDidLoad() {
        super.viewDidLoad()

        self.webView.navigationDelegate = self

        self.webView.configuration.userContentController.add(self, name: "controller")

        self.webView.loadFileURL(Bundle.main.url(forResource: "Main", withExtension: "html")!, allowingReadAccessTo: Bundle.main.resourceURL!)
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
#if STYLEPORT_DIRECT
        webView.evaluateJavaScript("showDirectDistribution()")
#endif
        SFSafariExtensionManager.getStateOfSafariExtension(withIdentifier: extensionBundleIdentifier) { (state, error) in
            guard let state = state, error == nil else {
                DispatchQueue.main.async {
                    if #available(macOS 13, *) {
                        webView.evaluateJavaScript("show(undefined, true, true)")
                    } else {
                        webView.evaluateJavaScript("show(undefined, false, true)")
                    }
                }
                return
            }

            DispatchQueue.main.async {
                if #available(macOS 13, *) {
                    webView.evaluateJavaScript("show(\(state.isEnabled), true)")
                } else {
                    webView.evaluateJavaScript("show(\(state.isEnabled), false)")
                }
            }
        }
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let action = message.body as? String else { return }

        switch action {
#if STYLEPORT_DIRECT
        case "check-for-updates":
            (NSApp.delegate as? AppDelegate)?.checkForUpdates()
#endif
        case "open-tip-jar":
            TipJarController.shared.present()
        case "open-preferences":
            SFSafariApplication.showPreferencesForExtension(withIdentifier: extensionBundleIdentifier) { _ in
                DispatchQueue.main.async {
                    NSApplication.shared.terminate(nil)
                }
            }
        case "open-publisher":
            if let url = URL(string: "https://relaybyte.dev") {
                NSWorkspace.shared.open(url)
            }
        case "open-privacy":
            if let url = URL(string: "https://styleport.app/privacy/") {
                NSWorkspace.shared.open(url)
            }
        default:
            return
        }
    }

}
