import AppKit
import RevenueCat

/// Optional consumable tips. No product grants access to StylePort features.
@MainActor
final class TipJarController: NSWindowController {
    static let shared = TipJarController()
    static let productIDs = [
        // Preserve the existing Apple product; product IDs are immutable.
        "com.kylereddoch.StylePort.tip.199",
        "dev.relaybyte.styleport.tip.medium",
        "dev.relaybyte.styleport.tip.large",
        "dev.relaybyte.styleport.tip.generous",
        "dev.relaybyte.styleport.tip.outstanding",
    ]

    private var packages: [Package] = []
    private var buttons: [NSButton] = []
    private var loading = false
    private var purchasing = false
    private let status = NSTextField(wrappingLabelWithString: "")
    private let choices = NSStackView()
    private let retry = NSButton(title: "Reload tip options", target: nil, action: nil)

    private init() {
        let window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 440, height: 340),
                              styleMask: [.titled, .closable], backing: .buffered, defer: false)
        window.title = "Support StylePort"
        window.isReleasedWhenClosed = false
        super.init(window: window)

        let heading = NSTextField(labelWithString: "Enjoying StylePort?")
        heading.font = .boldSystemFont(ofSize: 22)
        let description = NSTextField(wrappingLabelWithString:
            "Leave an optional, one-time tip to support development. Every feature stays free. Tips do not unlock anything and are not subscriptions.")
        let privacy = NSTextField(wrappingLabelWithString:
            "Apple and RevenueCat process tips and anonymous purchase records. Your styles and browsing history are never sent to RevenueCat.")
        privacy.font = .systemFont(ofSize: 11)
        privacy.textColor = .secondaryLabelColor
        choices.orientation = .vertical
        choices.alignment = .leading
        choices.spacing = 8
        status.font = .systemFont(ofSize: 12)
        status.textColor = .secondaryLabelColor
        status.setAccessibilityIdentifier("tip-status")
        retry.target = self
        retry.action = #selector(reload)
        retry.bezelStyle = .rounded

        let stack = NSStackView(views: [heading, description, choices, status, retry, privacy])
        stack.orientation = .vertical
        stack.alignment = .leading
        stack.spacing = 16
        stack.translatesAutoresizingMaskIntoConstraints = false
        let content = window.contentView!
        content.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: content.leadingAnchor, constant: 28),
            stack.trailingAnchor.constraint(equalTo: content.trailingAnchor, constant: -28),
            stack.topAnchor.constraint(equalTo: content.topAnchor, constant: 26),
            stack.bottomAnchor.constraint(lessThanOrEqualTo: content.bottomAnchor, constant: -24),
            description.widthAnchor.constraint(equalTo: stack.widthAnchor),
            status.widthAnchor.constraint(equalTo: stack.widthAnchor),
            choices.widthAnchor.constraint(equalTo: stack.widthAnchor),
            privacy.widthAnchor.constraint(equalTo: stack.widthAnchor),
        ])
        window.setContentSize(NSSize(width: 460, height: 540))
        window.center()
    }

    required init?(coder: NSCoder) { fatalError("Use the shared tip jar") }

    private func configurePurchasesIfNeeded() -> Bool {
        guard !Purchases.isConfigured else { return true }
        let key = (Bundle.main.object(forInfoDictionaryKey: "StylePortRevenueCatPublicKey") as? String ?? "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        guard key.hasPrefix("appl_"), key.count > 10 else {
            status.stringValue = "Tips are not configured in this build. Every StylePort feature is still free."
            return false
        }
        // Initialize only when someone opens the tip jar, not during ordinary
        // styling. RevenueCat owns verification and transaction finishing.
        Purchases.logLevel = .error
        Purchases.configure(with: .builder(withAPIKey: key)
            .with(storeKitVersion: .storeKit2)
            .with(automaticDeviceIdentifierCollectionEnabled: false)
            .build())
        return true
    }

    func present() {
        showWindow(nil)
        window?.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
        if packages.isEmpty { reload() }
    }

    @objc private func reload() {
        guard !loading, !purchasing else { return }
        guard configurePurchasesIfNeeded() else { return }
        loading = true
        retry.isEnabled = false
        status.stringValue = "Loading tip options from Apple and RevenueCat…"
        Task {
            defer { loading = false; retry.isEnabled = true }
            do {
                let offerings = try await Purchases.shared.offerings()
                let offeringID = Bundle.main.object(forInfoDictionaryKey: "StylePortRevenueCatTipOffering") as? String ?? "tips"
                let available = offerings.offering(identifier: offeringID)?.availablePackages ?? []
                var seen = Set<String>()
                packages = available.filter {
                    Self.productIDs.contains($0.storeProduct.productIdentifier)
                        && $0.storeProduct.productType == .consumable
                        && seen.insert($0.storeProduct.productIdentifier).inserted
                }.sorted { $0.storeProduct.price < $1.storeProduct.price }
                for button in buttons {
                    choices.removeArrangedSubview(button)
                    button.removeFromSuperview()
                }
                buttons = packages.enumerated().map { index, package in
                    let product = package.storeProduct
                    let button = NSButton(title: "\(product.localizedTitle) — \(product.localizedPriceString)",
                                          target: self, action: #selector(buy(_:)))
                    button.tag = index
                    button.bezelStyle = .rounded
                    button.setAccessibilityIdentifier(product.productIdentifier)
                    choices.addArrangedSubview(button)
                    button.widthAnchor.constraint(equalTo: choices.widthAnchor).isActive = true
                    button.heightAnchor.constraint(greaterThanOrEqualToConstant: 32).isActive = true
                    return button
                }
                status.stringValue = packages.isEmpty
                    ? "Tips are not available right now. You can keep using every StylePort feature for free."
                    : "Apple will ask you to confirm before completing a tip. TestFlight purchases are test transactions and do not charge you."
            } catch {
                status.stringValue = "Tips are temporarily unavailable. Please try again later. Every StylePort feature remains free."
            }
        }
    }

    @objc private func buy(_ sender: NSButton) {
        guard !purchasing, !loading, packages.indices.contains(sender.tag) else { return }
        let package = packages[sender.tag]
        purchasing = true
        buttons.forEach { $0.isEnabled = false }
        retry.isEnabled = false
        status.stringValue = "Waiting for Apple’s purchase confirmation…"
        Task {
            defer {
                purchasing = false
                buttons.forEach { $0.isEnabled = true }
                retry.isEnabled = true
            }
            do {
                // Anchor StoreKit's confirmation to the visible tip window.
                // This keeps presentation attached to the user's purchase UI.
                let params = PurchaseParams.Builder(package: package)
                if #available(macOS 15.2, *), let window = self.window {
                    window.makeKeyAndOrderFront(nil)
                    _ = params.with(confirmInWindow: window)
                }
                let result = try await Purchases.shared.purchase(params.build())
                status.stringValue = result.userCancelled
                    ? "Tip cancelled. Thank you for using StylePort."
                    : "Thank you for supporting StylePort! Every feature remains free."
            } catch {
                status.stringValue = (error as NSError).code == ErrorCode.paymentPendingError.rawValue
                    ? "Your tip is awaiting Apple's approval. No action is needed right now."
                    : "The tip could not be completed. Please try again later."
            }
        }
    }

}
