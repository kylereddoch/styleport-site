# StylePort

> Bring your style to the web.

StylePort is a privacy-first UserCSS manager with first-class Safari support. It
installs, configures, edits, updates, and applies website themes while keeping
styles and settings on your device.

Version 1.0 is being prepared for macOS Safari. The shared WebExtension codebase
also provides a path to iOS, Chromium, and Firefox builds.

## Current foundation

StylePort is a downstream project based on the mature, GPL-licensed
[Stylus](https://github.com/openstyles/stylus) engine. That foundation already
provides battle-tested UserCSS metadata parsing, `@var` configuration controls,
CSS/Less/Stylus compilation, URL matching, editing, backups, and updates.
StylePort's work focuses on Safari compatibility, native packaging, a cohesive
product experience, and reliable testing on WebKit.

## Development

Requirements:

- Node.js 24 or newer
- pnpm 11.8.0
- Xcode with the Safari Web Extension packager

Install and build the Safari extension resources:

```sh
npx pnpm@11.8.0 install --frozen-lockfile
npx pnpm@11.8.0 test
npx pnpm@11.8.0 release-safari
```

The browser-loadable extension is written to `dist-safari/` and synchronized
with the Xcode extension resources. On current Safari, it can be loaded locally
without a paid Apple Developer account from **Safari Settings > Developer > Add
Temporary Extension**.

The generated macOS container project lives in `safari/StylePort/StylePort.xcodeproj`.
New identifiers follow the [RelayByte naming convention](docs/NAMING-CONVENTION.md).

## Privacy

StylePort contains no advertising or browsing-history collection. Optional
App Store tips use Apple and RevenueCat for purchase processing and purchase
analytics; the billing integration does not receive your styles or browsing history.
Broad website access is required solely to apply user-selected styles to the
pages whose URLs they match.

See the full [privacy policy](PRIVACY.md), [security policy](SECURITY.md), and
[Safari release process](docs/RELEASING.md). A public App Store build additionally
requires an Apple Developer team, signed archive, App Store Connect listing, and
publicly reachable privacy-policy and support URLs.

## License and attribution

StylePort is licensed under GPL-3.0-only. It is based on Stylus and retains the
full upstream Git history, copyright notices, and contributor attribution.

- StylePort changes: Copyright 2026 Kyle Reddoch and contributors
- Upstream foundation: Copyright 2017-2026 Stylus Team and contributors
